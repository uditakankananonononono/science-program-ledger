"""Locked-design DEV recording-prefix association only. No synchronized/causal early-task claim."""
import os,json,csv,hashlib,platform
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,pandas as pd
from scipy.signal import butter,sosfilt,welch
from scipy.stats import t
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GroupKFold
P=Path(__file__).parent;DEV={f'Sub{i}' for i in range(3,35,2)};TASKS=['StSh25','StSh45','DySh25','DySh45','StEl25','StEl45','DyEl25','DyEl45'];EX={('Sub7','StSh25'),('Sub11','StEl45'),('Sub21','StEl25')};ASSUMPTION='First10seconds PROVIDED RECORDING origin, task onset unknown; no causal earlytask/synchronized endurance claim. Same-dataset second look after timedRPE failure.'
def table(name):
 out={}
 with (P/f'subject_tables/Subject_Data/{name}.csv').open() as f:
  r=csv.reader(f);h=next(r)
  for v in r:
   try:s='Sub'+str(int(float(v[0])))
   except:continue
   if s in DEV:out[s]=dict(zip(h,v))
 return out
def number(row,key):
 try:return float(row[key])
 except:return np.nan
T=table('Task_Times');F={j:table('Forces_'+j) for j in ['El','Sh']};I=table('Personal_Info');A=table('Anthropometrics');manifest={x['name']:x for x in json.loads((P/'dev_extraction_manifest.json').read_text())};assert json.loads((P/'sensor_md5_verified.json').read_text())['actual']=='md5:6a29192232b45d1f59ef16cf45c09145'
sos=butter(4,[20,450],fs=1000,btype='bandpass',output='sos')
def features(x):
 rms=np.sqrt(np.mean(x*x,axis=0));freq,power=welch(x,fs=1000,nperseg=1024,axis=0);total=power.sum(0)+1e-20;med=freq[(np.cumsum(power,axis=0)>=total[None,:]/2).argmax(0)];mean=(power*freq[:,None]).sum(0)/total
 return np.r_[np.log10(rms+1e-8),med/100,mean/100],rms
rows=[];audit=[]
for sid in sorted(DEV,key=lambda s:int(s[3:])):
 for task in TASKS:
  if (sid,task) in EX:audit.append({'subject':sid,'task':task,'excluded':'publisher missing/partial/comment'});continue
  label=number(T[sid],task)
  if not np.isfinite(label) or label<=0:audit.append({'subject':sid,'task':task,'excluded':'invalidtarget'});continue
  path=P/f'DEV_EMG/{sid}/EMG/{task}.csv';m=manifest[f'Sensor_Data/{sid}/EMG/{task}.csv'];assert hashlib.sha256(path.read_bytes()).hexdigest()==m['sha256']
  d=pd.read_csv(path,usecols=['Time','Del','Trap','Bicep','Tricep','Lat'],nrows=10001);d=d.loc[d.Time<=10];clock=d.Time.to_numpy();x=d[['Del','Trap','Bicep','Tricep','Lat']].to_numpy();n1=np.sum(clock<=5);n2=np.sum(clock>5)
  if len(d)<9500 or n1<4750 or n2<4750 or not np.isfinite(x).all() or not(np.diff(clock)>0).all() or np.diff(clock).max()>.1 or clock[-1]<9.999 or (x.var(0)==0).any():audit.append({'subject':sid,'task':task,'excluded':'prefixquality'});continue
  z=sosfilt(sos,x,axis=0);whole,rms=features(z[500:]);h1,_=features(z[:n1][500:]);h2,_=features(z[n1:]);joint=task[2:4];load=task[-2:];force=F[joint][sid];metadata=np.r_[np.eye(8)[TASKS.index(task)],number(force,f'Load_{joint}{load}'),number(force,f'SI_{joint}{load}'),number(force,'ElFMean' if joint=='El' else 'ShF_Mean'),number(I[sid],'Age'),1 if I[sid].get('Sex')=='M' else(0 if I[sid].get('Sex')=='F' else np.nan),number(I[sid],'Height'),number(I[sid],'Weight'),number(A[sid],'UpperarmL'),number(A[sid],'ForearmL'),number(A[sid],'HandL')]
  rows.append({'subject':sid,'task':task,'y':label,'meta':metadata.tolist(),'raw':np.r_[metadata,whole].tolist(),'halves':np.r_[metadata,whole,h1,h2].tolist(),'candidate':np.r_[metadata,whole,rms/(rms.sum()+1e-20),h2-h1].tolist()});audit.append({'subject':sid,'task':task,'included':True})
assert all(r['subject'] in DEV for r in rows);g=np.array([r['subject'] for r in rows]);yy=np.array([r['y'] for r in rows]);X={k:np.array([r[k] for r in rows]) for k in ['meta','raw','halves','candidate']}
baselines=[(k,'ridge',a) for k in ['meta','raw','halves'] for a in [1,10,100]]+[(k,'rf',a) for k in ['raw','halves'] for a in [5,10,20]];candidates=[('candidate','ridge',a) for a in [1,10,100]]+[('candidate','rf',a) for a in [5,10,20]]
def weights(idx):
 gr=g[idx];w=np.array([1/(gr==s).sum() for s in gr]);return w/w.mean()
def score(y,idx,p):return float(np.average(abs(y[idx]-p),weights=weights(idx)))
def model(kind,a):return make_pipeline(SimpleImputer(strategy='median',keep_empty_features=True),StandardScaler(),Ridge(alpha=a)) if kind=='ridge' else make_pipeline(SimpleImputer(strategy='median',keep_empty_features=True),RandomForestRegressor(n_estimators=100,max_depth=10,min_samples_leaf=a,random_state=161,n_jobs=1))
def fit(y,idx,spec):
 k,kind,a=spec;m=model(kind,a);m.fit(X[k][idx],y[idx],**{('ridge' if kind=='ridge' else 'randomforestregressor')+'__sample_weight':weights(idx)});return m
results=[]
for perm in [False,True]:
 y=np.random.default_rng(161).permutation(yy) if perm else yy.copy();pred={k:np.full(len(y),np.nan) for k in ['baseline','candidate','null']};folds=[]
 for fold,(train,test) in enumerate(GroupKFold(4).split(X['meta'],y,g)):
  selected={}
  for name,specs in [('baseline',baselines),('candidate',candidates)]:
   vals=[]
   for spec in specs:
    pp=np.full(len(train),np.nan)
    for ia,ib in GroupKFold(3).split(X[spec[0]][train],y[train],g[train]):
     a,b=train[ia],train[ib];m=fit(y,a,spec);pp[ib]=m.predict(X[spec[0]][b])
    vals.append(score(y,train,pp))
   win=int(np.argmin(vals));spec=specs[win];m=fit(y,train,spec);pred[name][test]=m.predict(X[spec[0]][test]);selected[name]={'spec':spec,'inner_scores':list(zip(specs,vals))}
  pred['null'][test]=np.median(y[train]);folds.append({'fold':fold,'train':sorted(set(g[train])),'test':sorted(set(g[test])),'selected':selected});print('FOLD',perm,fold,selected['baseline']['spec'],selected['candidate']['spec'],flush=True)
 subs=[]
 for s in sorted(set(g),key=lambda s:int(s[3:])):
  ix=np.flatnonzero(g==s);e={k:score(y,ix,p[ix]) for k,p in pred.items()};subs.append({'subject':s,'n':len(ix),**e,'gain':e['baseline']-e['candidate']})
 gains=np.array([r['gain'] for r in subs]);boot=np.random.default_rng(161).choice(gains,(2000,len(gains)),replace=True).mean(1);ci=np.quantile(boot,[.025,.975]);sd=gains.std(ddof=1);power={}
 for assumedSD in [5,10,20,40]:
  sim=np.random.default_rng(161).normal(5,assumedSD,(10000,16));lo=sim.mean(1)-t.ppf(.975,15)*sim.std(1,ddof=1)/4;power[str(assumedSD)]={'positive_interval':float((lo>0).mean()),'full_WIN':float(((lo>0)&(sim.mean(1)>=5)).mean())}
 observed=np.random.default_rng(161).normal(gains.mean(),max(sd,1e-9),(10000,16));lo=observed.mean(1)-t.ppf(.975,15)*observed.std(1,ddof=1)/4;result={'assumption':ASSUMPTION,'perm':perm,'n':len(y),'subject_count':len(subs),'subject_MAE':{k:float(np.mean([s[k] for s in subs])) for k in pred},'gain':float(gains.mean()),'CI':ci.tolist(),'subjects':subs,'folds':folds,'label_free_power_assumedSD_at5seconds':power,'DEV_selected_effect_power_optimistic':float((lo>0).mean()),'DEV_MDE80':float((t.ppf(.975,15)+.8416)*sd/4),'predictions':[{'subject':r['subject'],'task':r['task'],'y':float(y[i]),**{k:float(v[i]) for k,v in pred.items()}} for i,r in enumerate(rows)]};results.append(result);(P/f'endurance_result_{"perm" if perm else "real"}.json').write_text(json.dumps(result,indent=2));print('RESULT',perm,result['subject_MAE'],result['gain'],result['CI'],flush=True)
(P/'endurance_features_DEV.json').write_text(json.dumps({'assumption':ASSUMPTION,'rows':rows,'audit':audit},indent=2))
