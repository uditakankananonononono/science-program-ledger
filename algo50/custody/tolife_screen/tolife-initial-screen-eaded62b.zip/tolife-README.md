# Clinical Health Indices Dataset - TOLIFE Project

## Overview

This dataset contains clinical health indices collected as part of the TOLIFE project (Combining Artificial Intelligence and smart sensing TOward better management and improved quality of LIFE in COPD, Grant Agreement No. 101057103), which clinically validates an artificial intelligence solution to process daily life patient data captured by unobtrusive sensors for COPD (Chronic Obstructive Pulmonary Disease) monitoring. The data represents continuous monitoring of health parameters from participants across multiple European locations between 2024 and 2025.

In addition to the sensor-derived health indices, the dataset includes clinically annotated information such as COPD exacerbation events—classified by severity—and detailed clinical and demographic data collected during scheduled clinical visits (timepoints T1,T2,T3,T4,T5) with healthcare professionals. These additional sources provide important context for interpreting the sensor data, capturing aspects such as disease progression, patient-reported outcomes, and comorbidities.

## Dataset Structure

The dataset is organized in a hierarchical structure:

```
index/
├── GERMANY/
│   └── GER-XXX/                 # Individual participant directories
│       ├── EI.csv               # Environmental Index
│       ├── SHRI.csv             # Sleeping Heart Rate Index
│       ├── SII.csv              # Sound Intensity Index
│       ├── MI.csv               # Mobility Index
│       ├── BRI.csv              # Breathing Rate Index
│       ├── SQI.csv              # Sleep Quality Index
│       ├── PRVI.csv             # PPG Pulse Rate Variability Index
│       ├── PEI.csv              # Pulmonary Efficiency Index
│       ├── clinical_indices.csv # Clinical and demographic data
│       └── exacerbations.csv    # Exacerbations data (when present)
└── SPAIN/
    └── SPA-XXX/                 # Individual participant directories
        ├── EI.csv               # Environmental Index
        ├── SHRI.csv             # Sleeping Heart Rate Index
        ├── SII.csv              # Sound Intensity Index
        ├── MI.csv               # Mobility Index
        ├── BRI.csv              # Breathing Rate Index
        ├── SQI.csv              # Sleep Quality Index
        ├── PRVI.csv             # PPG Pulse Rate Variability Index
        ├── PEI.csv              # Pulmonary Efficiency Index
        ├── clinical_indices.csv # Clinical and demographic data
        └── exacerbations.csv    # Exacerbations data (when present)
```

## Data Collection Period

- **Start Date**: May 21, 2024
- **Data Coverage**: May 2024 to May 2025
- **Collection Frequency**: Daily measurements with hourly/sub-hourly resolution for some parameters
- **Status**: Data collection is ongoing; this dataset represents the first year of monitoring

## Participant Information

### Germany
- **Total Participants**: 34 active monitoring participants
- **Kit ID Format**: GER-XXX (3-digit sequential numbering)
- **Location**: Germany

### Spain  
- **Total Participants**: 40 active monitoring participants
- **Kit ID Format**: SPA-XXX (3-digit sequential numbering)
- **Location**: Spain

## Clinical Indices Overview

| File Name | Index Type | Full Name | Description |
|-----------|------------|-----------|-------------|
| `EI.csv` | Environmental Index | Environmental Index | Environmental conditions (temperature, humidity, air quality, light) |
| `SHRI.csv` | Sleeping Heart Rate Index | Sleeping Heart Rate Index | Cardiovascular parameters during sleep |
| `SII.csv` | Sound Intensity Index | Sound Intensity Index | Audio-based health monitoring and sound measurements |
| `MI.csv` | Mobility Index | Mobility Index | Physical activity and movement patterns |
| `BRI.csv` | Breathing Rate Index | Breathing Rate Index | Respiratory frequency and breathing patterns |
| `SQI.csv` | Sleep Quality Index | Sleep Quality Index | Sleep efficiency and quality indicators |
| `PRVI.csv` | Pulse Rate Variability Index | pulse_rate_Variability_index | PPG smartwatch data including heart rate variability metrics |
| `PEI.csv` | Pulmonary Efficiency Index | Spirometer pulmonary_efficiency_index | Spirometry measurements including FEV1 and PEF parameters |
| `clinical_indices.csv` | Clinical Data | Clinical Indices | Patient demographics, clinical measurements, and questionnaire scores |
| `exacerbations.csv` | Exacerbations Data | Exacerbations Data | Clinical exacerbation events with severity classification |

## Data Types and Parameters

### 1. Environmental Index (`EI.csv`)
Environmental conditions measured in the participant's sleep environment:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| Timestamp | UTC timestamp in ISO8601 format | YYYY-MM-DDTHH:MM:SSZ | datetime |
| Mean_Temp | Average temperature | °C | float |
| Std_Temp | Temperature standard deviation | °C | float |
| Max_Temp | Maximum temperature | °C | float |
| Min_Temp | Minimum temperature | °C | float |
| Mean_Hum | Average humidity | % | float |
| Std_Hum | Humidity standard deviation | % | float |
| Max_Hum | Maximum humidity | % | float |
| Min_Hum | Minimum humidity | % | float |
| Mean_AQI | Average Air Quality Index | AQI scale (0-500) | float |
| Std_AQI | AQI standard deviation | AQI scale (0-500) | float |
| Max_AQI | Maximum AQI | AQI scale (0-500) | float |
| Min_AQI | Minimum AQI | AQI scale (0-500) | float |
| Mean_Lux | Average light intensity | lux | float |
| Std_Lux | Light intensity standard deviation | lux | float |
| Max_Lux | Maximum light intensity | lux | float |
| Min_Lux | Minimum light intensity | lux | float |
| index_validity | Data quality flag | 0/1 | integer |
| data_validity | Data availability flag | 0/1 | integer |

### 2. Sleeping Heart Rate Index (`SHRI.csv`)
Cardiovascular monitoring parameters during sleep:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| Timestamp | UTC timestamp in ISO8601 format | YYYY-MM-DDTHH:MM:SSZ | datetime |
| hr_mean | Average heart rate | bpm | float |
| hr_std | Heart rate standard deviation | bpm | float |
| hr_max | Maximum heart rate | bpm | float |
| hr_min | Minimum heart rate | bpm | float |
| index_validity | Data quality flag | 0/1 | integer |
| data_validity | Data availability flag | 0/1 | integer |

### 3. Sound Intensity Index (`SII.csv`)
Audio-based health monitoring and sound intensity measurements:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| Timestamp | UTC timestamp in ISO8601 format | YYYY-MM-DDTHH:MM:SSZ | datetime |
| Mean_SI | Average sound intensity | dimensionless | float |
| Std_SI | Sound intensity standard deviation | dimensionless | float |
| Max_SI | Maximum sound intensity | dimensionless | float |
| Min_SI | Minimum sound intensity | dimensionless | float |
| index_validity | Data quality flag | 0/1 | integer |
| data_validity | Data availability flag | 0/1 | integer |

### 4. Mobility Index (`MI.csv`)
Physical activity and movement indices:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| timestamp | UTC timestamp in ISO8601 format | YYYY-MM-DDTHH:MM:SSZ | datetime |
| gs_mean | Average gait speed | m/s | float |
| gs_std | Gait speed standard deviation | m/s | float |
| sl_mean | Average step length | m | float |
| sl_std | Step length standard deviation | m | float |
| smwd_mean | Average six-minute walk distance | meters | float |
| smwd_std | Six-minute walk distance std dev | meters | float |
| walked_time | Total walking time | minutes | float |
| walked_dist | Total distance walked | meters | float |
| index_validity | Data quality flag | 0/1 | integer |
| data_validity | Data availability flag | 0/1 | integer |

### 5. Breathing Rate Index (`BRI.csv`)
Breathing pattern monitoring and respiratory frequency analysis during sleep phase:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| Timestamp | UTC timestamp in ISO8601 format | YYYY-MM-DDTHH:MM:SSZ | datetime |
| rf_mean | Average respiratory frequency | breaths/min | float |
| rf_std | Respiratory frequency standard deviation | breaths/min | float |
| rf_max | Maximum respiratory frequency | breaths/min | float |
| rf_min | Minimum respiratory frequency | breaths/min | float |
| index_validity | Data quality flag | 0/1 | integer |
| data_validity | Data availability flag | 0/1 | integer |

### 6. Sleep Quality Index (`SQI.csv`)
Sleep pattern and quality metrics:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| Timestamp | UTC timestamp in ISO8601 format | YYYY-MM-DDTHH:MM:SSZ | datetime |
| sleep_duration | Total sleep duration | hours | float |
| num_movements | Number of movements during sleep | count | integer |
| WASO | Wake After Sleep Onset | hours | float |
| SE | Sleep Efficiency | % | float |
| index_validity | Data quality flag | 0/1 | integer |
| data_validity | Data availability flag | 0/1 | integer |

### 7. Pulmonary Efficiency Index (`PEI.csv`)
Spirometry measurements including FEV1 and PEF parameters:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| Timestamp | UTC timestamp in ISO8601 format | YYYY-MM-DDTHH:MM:SSZ | datetime |
| mean_FEV1 | Average Forced Expiratory Volume in 1 second | cL | float |
| range_FEV1_low | FEV1 range lower bound | cL | float |
| range_FEV1_high | FEV1 range upper bound | cL | float |
| mean_PEF | Average Peak Expiratory Flow | cL/min | float |
| range_PEF_low | PEF range lower bound | cL/min | float |
| range_PEF_high | PEF range upper bound | cL/min | float |
| HR | Heart rate | bpm | float |
| SpO2 | Blood oxygen saturation | % | float |
| data_validity | Data availability flag | 0/1 | integer |
| index_validity | Data quality flag | 0/1 | integer |

### 8. PPG Pulse Rate Variability Index (`PRVI.csv`)
PPG smartwatch data including heart rate variability metrics:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| Timestamp | UTC timestamp in ISO8601 format | YYYY-MM-DDTHH:MM:SSZ | datetime |
| mean_HR | Average heart rate | bpm | float |
| range_HR_low | Heart rate range lower bound | bpm | float |
| range_HR_high | Heart rate range upper bound | bpm | float |
| std_RR | Standard deviation of RR intervals | ms | float |
| range_stdRR_low | StdRR range lower bound | ms^2 | float |
| range_stdRR_high | StdRR range upper bound | ms^2 | float |
| RMSSD | Root Mean Square of Successive Differences | ms | float |
| range_RMSSD_low | RMSSD range lower bound | ms^2 | float |
| range_RMSSD_high | RMSSD range upper bound | ms^2 | float |
| data_validity | Data availability flag | 0/1 | integer |
| index_validity | Data quality flag | 0/1 | integer |
| nRMSSD | Normalized RMSSD | ms^2/bpm | float |
| range_nRMSSD_low | nRMSSD range lower bound | ms^2/bpm | float |
| range_nRMSSD_high | nRMSSD range upper bound | ms^2/bpm | float |

### 9. Exacerbations Data (`exacerbations.csv`)
Clinical exacerbation events with severity classification:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| Timestamp | UTC timestamp in ISO8601 format | YYYY-MM-DD HH:MM:SS | datetime |
| PatientId | Patient identification number | - | integer |
| Kit-id | Participant kit identifier | - | string |
| Type | Exacerbation severity level | Moderate/Severe | string |

**Note**: The `exacerbations.csv` file is only present for participants who experienced clinical exacerbation events during the monitoring period. If this file is absent from a participant's directory, it indicates that no exacerbations were recorded for that participant.

### 10. Clinical Indices Data (`clinical_indices.csv`)
Patient demographic information, clinical measurements, and standardized questionnaire scores collected at multiple timepoints:

| Column | Description | Unit | Data Type |
|--------|-------------|------|-----------|
| Patient-ID | Patient identification number | - | integer |
| Timepoint | Study visit timepoint | T1-T5 | string |
| Visit Date | Date of clinical visit | YYYY-MM-DD | date |
| Year of Birth | Patient birth year | - | integer |
| Sex | Patient biological sex | Male/Female | string |
| Height (cm) | Patient height | cm | float |
| Weight (kg) | Patient weight | kg | float |
| FEV1 (L) | Forced Expiratory Volume in 1 second | L | float |
| FEV1_pred (%) | FEV1 percentage of predicted | % | float |
| FVC (L) | Forced Vital Capacity | L | float |
| FVC_pred (%) | FVC percentage of predicted | % | float |
| Lung Ratio | FEV1/FVC ratio | - | float |
| DLCO | Diffusing capacity of the lungs for carbon monoxide | - | float |
| DLCO_pred (%) | DLCO percentage of predicted | % | float |
| CAT Score | COPD Assessment Test score | - | integer |
| mMRC Score | Modified Medical Research Council dyspnea scale | - | integer |
| CCQ Total Score | Clinical COPD Questionnaire total score | - | float |
| CCQ Symptom | CCQ symptom domain score | - | float |
| CCQ Functional | CCQ functional domain score | - | float |
| CCQ Mental | CCQ mental domain score | - | float |
| Systolic BP (mmHg) | Systolic blood pressure | mmHg | integer |
| Diastolic BP (mmHg) | Diastolic blood pressure | mmHg | integer |
| Heart Rate (bpm) | Resting heart rate | bpm | integer |
| Oxygen Saturation (%) | Blood oxygen saturation | % | integer |
| EQ5D Mobility | EuroQol-5D mobility dimension | 1-5 | integer |
| EQ5D Self Care | EuroQol-5D self-care dimension | 1-5 | integer |
| EQ5D Usual Activities | EuroQol-5D usual activities dimension | 1-5 | integer |
| EQ5D Pain/Discomfort | EuroQol-5D pain/discomfort dimension | 1-5 | integer |
| EQ5D Anxiety/Depression | EuroQol-5D anxiety/depression dimension | 1-5 | integer |
| EQ5D Health Score | EuroQol-5D visual analogue scale | 0-100 | integer |
| Anxiety HADS | Hospital Anxiety and Depression Scale - Anxiety | - | integer |
| Depression HADS | Hospital Anxiety and Depression Scale - Depression | - | integer |
| Total PSQI Score | Pittsburgh Sleep Quality Index total score | - | integer |
| Sleep Efficiency (%) | Sleep efficiency percentage | % | float |
| Six-Minute Walk Distance (m) | Six-minute walk test distance | meters | float |

**Note**: This file contains longitudinal clinical data collected at multiple timepoints (T1-T5) throughout the study period. Empty cells indicate measurements that were not collected or not applicable at that timepoint.

## Data Quality Indicators

Each measurement includes two quality flags:

- **index_validity**: Indicates whether the calculated health index is valid (1) or invalid (0)
- **data_validity**: Indicates whether the raw sensor data was available (1) or missing (0)

## Data Processing

### Timestamp Standardization
All timestamps have been automatically converted to UTC timezone in ISO8601 format (`YYYY-MM-DDTHH:MM:SSZ`) for consistency across different data collection sites and local timezone differences.

### Data Consolidation
Individual daily files for each parameter type have been merged into single CSV files per participant kit, maintaining chronological order and removing duplicate entries.

## Technical Specifications

### File Format
- **Format**: CSV (Comma-Separated Values)
- **Encoding**: UTF-8
- **Delimiter**: Comma (,)
- **Decimal Separator**: Period (.)
- **Missing Values**: Empty cells or explicit null values

### Data Volume
- **Total Participants**: 74 (34 German + 40 Spanish)
- **Individual Index Files**: 592 files (8 indices × 74 participants)
- **Clinical Data Files**: 74 files (1 per participant)
- **Exacerbation Files**: Variable (only for participants with recorded exacerbations)
- **Collection Duration**: 12 months (May 2024 - May 2025)

## Ethical Considerations

This study was conducted in accordance with ethical guidelines for clinical research:
- Ethics committee approval obtained from participating institutions
- Written informed consent obtained from all participants
- Data has been anonymized with participant identifiers replaced by kit IDs
- Privacy protection measures implemented throughout data collection and processing
- Participants had the right to withdraw from the study at any time

## Associated Publications

Further details about the TOLIFE project methodology, sensor technologies, and analysis approaches can be found in the following publications:

1. Zanoletti, M., Bufano, P., Bossi, F., Di Rienzo, F., Marinai, C., Rho, G., Vallati, C., Carbonaro, N., Greco, A., Laurino, M., & Tognetti, A. (2024). Combining Different Wearable Devices to Assess Gait Speed in Real-World Settings. *Sensors*, 24(10), 3205. https://doi.org/10.3390/s24103205

2. Marinai, C., Arcarisi, L., Bossi, F., Bufano, P., Di Rienzo, F., Melissa, E., Rho, G., Zanoletti, M., Greco, A., Laurino, M., Vallati, C., Carbonaro, N., & Tognetti, A. (2024). Smart Mattress Cover for Unobtrusive Monitoring of Sleep-Quality Correlates in Real-Life. In *2024 IEEE SENSORS* (pp. 1-4). IEEE. https://doi.org/10.1109/SENSORS60989.2024.10784486

3. Rho, G., Carbonaro, N., Laurino, M., Tognetti, A., & Greco, A. (2024). Estimating Heart Rate Variability from Wrist-Worn Photoplethysmography Devices in Daily Activities: A Preliminary Convolutional Denoising Autoencoder Approach. In *2024 IEEE International Conference on Metrology for eXtended Reality, Artificial Intelligence and Neural Engineering (MetroXRAINE)* (pp. 207-212). IEEE. https://doi.org/10.1109/MetroXRAINE62247.2024.10796284

4. Carbonaro, N., Laurino, M., Greco, A., Marinai, C., Giannetti, F., Righetti, F., Di Rienzo, F., Rho, G., Arcarisi, L., Zanoletti, M., Bufano, P., Tesconi, M., Sgambelluri, N., Menicucci, D., Vallati, C., & Tognetti, A. (2024). Smart Sensors for Daily-Life Data Collection Toward Precision and Personalized Medicine: The TOLIFE Project Approach. In A. Badnjević & L. Gurbeta Pokvić (Eds.), *MEDICON'23 and CMBEBIH'23* (pp. 783-794). Springer Nature Switzerland. https://doi.org/10.1007/978-3-031-49062-0_82

5. Di Rienzo, F., Righetti, F., Laurino, M., Greco, A., Marinai, C., Di Mambro, I., Melissa, E., Carbonaro, N., Bossi, F., Rho, G., Arcarisi, L., Zanoletti, M., Bufano, P., Tognetti, A., & Vallati, C. (2024). Using Multiple Devices for Patient Monitoring in Clinical Studies: The TOLIFE Experience. In *2024 IEEE International Conference on Pervasive Computing and Communications Workshops and other Affiliated Events (PerCom Workshops)* (pp. 148-153). IEEE. https://doi.org/10.1109/PerComWorkshops59983.2024.10502767

6. G. Rho, N. Carbonaro, M. Laurino, A. Tognetti, and A. Greco, “A Convolutional Denoising Autoencoder approach for estimating Heart Rate Variability from wrist photoplethysmography devices in daily activities,” under review, Biomedical Signal Processing and Control, Elsevier.

7. M. Zanoletti, C. Vallati, N. Carbonaro, A. Greco, A. Tognetti, and Marco Laurino, "Real-World Gait Speed Estimation: an AI-based Approach for Adaptive Wearable Devices Integration," under review, Journal of Biomedical and Health Informatics, IEEE

8. Marinai, C., Melissa, E., Di Rienzo, F., Vallati, C., Laurino, M., Tognetti, A. & Carbonaro, N., (2025). "The Smart Mattress Cover System: a novel textile-based system for unobtrusive sleep correlates monitoring", submitted to IEEE Sensors Journal

9. Marinai, C. and Melissa, E., Arcarisi, L., Bossi, F., Bufano, P., Di Rienzo, F., Zanoletti, M., Greco, A., Vallati, C., Carbonaro, N., Laurino, M., & Tognetti, A. (2025). In-bed unobtrusive heart rate estimation using ballistocardiography and sensor fusion algorithm. Accepted to “E-Textiles: International Conference on the Challenges, Opportunities, Innovations and Applications in Electronic Textiles” (2025)

For the most current list of publications, please visit the project website: https://www.tolife-project.eu/

## Usage Guidelines

### Recommended Use Cases
- Longitudinal health monitoring research
- Sleep pattern analysis
- Environmental health impact studies
- Digital health technology validation
- Machine learning model development for health prediction

### Citation
If you use this dataset in your research, please cite:

```
TOLIFE Consortium. (2025). Clinical Health Indices Dataset - TOLIFE Project: 
Continuous monitoring of health parameters for COPD patients using unobtrusive sensors. 
Zenodo. https://doi.org/10.5281/zenodo.16642439
```

### License
This dataset is released under Creative Commons Attribution 4.0 International (CC BY 4.0) license.

## Data Availability Statement

This dataset is publicly available through Zenodo at: https://doi.org/10.5281/zenodo.16642439

## Contact Information

**Principal Investigator**: TOLIFE Consortium
**Data Contact**: For data-related inquiries, please contact the TOLIFE project team
**Institution**: University of Pisa, Italy (Lead Institution) and participating European institutions
**Project Website**: https://www.tolife-project.eu/

## Acknowledgments

The work is supported by European Union's Horizon Europe Research and Innovation Programme under grant agreement No. 101057103 – project TOLIFE.

We acknowledge the valuable contribution of all participant volunteers and the technical staff involved in data collection across Germany and Spain.

## Version History

- **v1.0** (2025): Initial dataset release
  - Consolidated daily measurements into participant-level files
  - Standardized timestamps to UTC format
  - Quality flags included for all measurements

## Known Issues and Limitations

- Some participants may have missing data periods due to participant non-compliance
- Data quality varies across participants and measurement periods (indicated by validity flags)
- Environmental and mobility measurements may be affected by local conditions and participant lifestyle
- Clinical assessments are available only at specific timepoints (T1-T5) and not continuously

## Support and Feedback

For questions about this dataset or to report issues, please:
- Visit the project website: https://www.tolife-project.eu/
- Contact the TOLIFE project team through the official project channels

---

*Last updated: July 31, 2025*