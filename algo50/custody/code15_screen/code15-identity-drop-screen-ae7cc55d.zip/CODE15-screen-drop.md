# CODE-15 RBBB: identity-gate DROP

Main ruling8Oct2026 14:21:23: NOT READY / identity-fail, no builder proposal. Actual metadata publisherMD5 0107516d3f63864498fb77d15799cc95 matches.345779uniqueexamIDs233770patientIDs;recordKish159679.15.6672RBBB-positivepeople;nominal25%TESTindependentHM80%MDE.02943atAUC.6/.02601at.8. Age/sex/Chagasmatching shrinks control ratio power;30%would be needed for conservative1:3but never locked becauseidentityfailed.

496IDs(0.212%)haveage-span>7yearsover2010-2016acquisitionwindow,1736exams,38RBBBpositivepeople;341IDs>10years,19>20years. Worst1023070ages18/23/100;18937920/100;49088421/24/100. Sexconsistentdoesnotproveidentity. Publisherdefinesageinyearsatexam;noexamdate,DOB,siteinpublictable. Authorsreposissuesandpaperdo not explain these discrepancies. Main rejects excluding496asfalseconfidence,not proofremainingclean.

Methodsconflict: agepaper https://pmc.ncbi.nlm.nih.gov/articles/PMC8387361/ describes age-stratified16-85first-examholdout;API https://zenodo.org/records/4916206 describesstratified15%patientssampling;actualage17-100withimpossiblewithinpersonspans. 2021exactCODE15CCBY4release differentfrom2020restrictedfullCODEtrainDUA;CCBYnotextendedtofullCODE.2020architecture https://www.nature.com/articles/s41467-020-15432-4 iscontext,notpublicCODE15testbenchmark;no pretrainedmodelused.

Official2025Chagaslabels ZIP https://moody-challenge.physionet.org/2025/data/code15_chagas_labels.zip CRCpasses343424examlabels2355unmatchedmetadataexams,0patientIDmismatch. RBBBpeople1020Chagas+/5549negative/103unknown;nonRBBB3424positive222195negative1479unknown.15.29%vs1.51%self-reportChagasconfound. NoChagasendpoint/featuresused,onlycounts. No waveform fetch/models/splits/scores/authorcontact/push. Wholewaveformarchivechecksumnotverified.
