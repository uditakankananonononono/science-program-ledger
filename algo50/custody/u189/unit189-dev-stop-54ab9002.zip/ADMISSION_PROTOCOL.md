# Unit 189 Shandong ECG - admission protocol draft

Source: Figshare collection5779802 v1, exact rawarticle17912444, metadata17912441 and dictionary17912507. All three exact live article APIs verifiedCC0. Metadata/dictionary verified against publisherMD5. Scout receipt reports whole raw uncompressed TAR, misleading filename records.tar.gz, MD5 0beef976f54cf0a95fac9f45bb157950/2281799680bytes. This build does not claim independent fullarchive hash yet. Complete byteoffset manifest and all25770shape-check receipt supplied; localDEV checks will inspect actual arrays and finitevalues.

Split fixed before waveform analysis: Patient_ID exactUTF8 bytes, SHA256, first8hex uint32; TEST iff uint<858993459, otherwiseDEV. Approximate20%; no rerolling, no stratification. Record labels normal only iff every semicolon-separated primarycode(before+) equals1; duplicate1;1 remainsnormal. Persontruth anyabnormalrecord; prediction max across person'srecords. GroupPatient_ID in every fold/bootstrap. Age/sex firstchronologicalrecord, ECG_ID lexical tie break. Agebands18-39/40-59/60-79/80+. Age can differ across repeatrecords (517DEVpeople have2values); earliest rule fixed, no averaging. Sex constant inDEV.

RealizedDEV19773people/20664records, TEST4893people(2277abnormal/2616normal) only aggregatecount-exposure. NoTEST waveform reads/scoring/tuning. Counts-only tables cover age/sex/length; leadset/order and500Hz sourceprovenance. Allshape receipt12xN, N5000-28000. SampleDEV A16843 has12x5000float16 and no rate/timeattributes. No interpolation/resampling/alignment choice yet fixed for models.

Counts-only HanleyMcNeil planning at fixedWINdelta.03: assumingAUC.8, independenttwo-estimateMDE80 .025503/power.90916; .9 MDE.018523/power.99502. This is assumedAUC and independence, not a matchedpairedcovariance or guarantee. Age-sexmatched sensitivity and power must be recomputed. Smallestsensitivityage80+ has fewercontrols; no assurance of80%power within eachband.

Original sourcepaper PMC9174207 proposes normal/abnormal task and patientaware split code, no trainedbenchmark comparator. No exactShandong published metric verified; do not borrow Shaoxing or ECGChat othercorpus results.

Method candidate, not approved/locked: beat-aligned multilead morphology quantiles and RR-change structure, compared to conventionalglobal-featureGBM and smalltrainednumpyCNN. No stacking or labelmanipulation. Both require explicitcostmatching and DEV tuninggrid before modeling. Mandatoryage-sex comparator and agebands; positive mustsurvive them. Familyproximity moderate vsPTBXL138/115 perparent, no pooling. No clinical/externalvalidity claim.

Sequencing unresolved: assignment requests pre-preregDEVheadroom andPERM for everygridmember, plus lockbeforeanyoutcomecompute. TreatDEVgate outcomecompute as allowedexception only after admission-grid protocol isconfirmed; allTEST compute remains prohibited. Full modelingprereg andrun.py hashes sent toparentbeforelockedoutcomerun. No pushes.
