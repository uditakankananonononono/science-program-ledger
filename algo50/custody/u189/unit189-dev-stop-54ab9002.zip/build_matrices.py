import pandas as pd,numpy as np,os,json,hashlib,time
r='/tmp/unit189/';d=pd.read_csv(r+'DEV_RECORDS.csv');d['fold']=d.Patient_ID.map(lambda x:int(hashlib.sha256((x+':189-cv').encode()).hexdigest()[:8],16)%3);d.to_csv(r+'DEV_INDEX.csv',index=False);n=len(d);g=np.zeros((n,148),'f');w=np.lib.format.open_memmap(r+'waves.npy',mode='w+',dtype='float16',shape=(n,12,1000));bc=[]
for i,row in enumerate(d.itertuples()):
 with np.load(r+'feature_cache/'+row.ECG_ID+'.npz') as x:g[i]=np.r_[x['globalf'],x['rr']];w[i]=x['wave'];bc.append(len(x['beats']))
np.save(r+'global.npy',g);w.flush();json.dump({'records':n,'wave_disk_shape':[n,12,1000],'global_features':148,'min_beats':min(bc),'max_beats':max(bc),'missing_beat_records':sum(x<2 for x in bc)},open(r+'MATRIX_STATUS.json','w'),indent=2)
