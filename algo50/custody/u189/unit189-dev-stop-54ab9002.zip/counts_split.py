import pandas as pd,numpy as np,hashlib,json,os
from scipy.stats import norm
r='/tmp/unit189/';d=pd.read_csv(r+'evidence/sph-metadata.csv',dtype={'Patient_ID':str,'ECG_ID':str,'AHA_Code':str,'Date':str});d['y']=d.AHA_Code.map(lambda x:any(t.split('+')[0].strip()!='1' for t in x.split(';'))).astype(int);d['split']=d.Patient_ID.map(lambda s:'TEST' if int(hashlib.sha256(s.encode('utf-8')).hexdigest()[:8],16)<858993459 else 'DEV');d['age_band']=pd.cut(d.Age,[17,39,59,79,np.inf],labels=['18-39','40-59','60-79','80+']);assert d.Patient_ID.groupby(d.Patient_ID).nunique().max()==1
p=d.sort_values(['Patient_ID','Date','ECG_ID'],kind='stable').groupby('Patient_ID',sort=False).first();p['y']=d.groupby('Patient_ID').y.max();p['records']=d.groupby('Patient_ID').size();print('People',len(p),'split',p.groupby(['split','y']).size().to_dict(),'records',len(d));print('lengths',d.N.value_counts().sort_index().to_dict())
# Sealed TEST outcomes are not written to modeling cache; counts-only contingency table, not outcome score.
d[d.split=='DEV'].to_csv(r+'DEV_RECORDS.csv',index=False);p[p.split=='DEV'].to_csv(r+'DEV_PEOPLE.csv');pd.DataFrame({'Patient_ID':p.index,'split':p['split'].values}).to_csv(r+'SPLIT_MANIFEST.csv',index=False)
cts=[]
for label,table in [('person',p),('record',d)]:
 for fields in [['split','y'],['age_band','Sex','y'],['N','y'] if label=='record' else ['records','y']]:
  for keys,n in table.groupby(fields,observed=True).size().items():cts.append({'unit':label,'fields':fields,'values':[str(x) for x in (keys if isinstance(keys,tuple) else (keys,))],'count':int(n)})
json.dump(cts,open(r+'COUNTS_ONLY_TABLES.json','w'),indent=2)
nt=p[p.split=='TEST'].y.value_counts();a,b=int(nt[1]),int(nt[0]);power=[]
for auc in [.8,.9,.95]:
 q1=auc/(2-auc);q2=2*auc*auc/(1+auc);var=(auc*(1-auc)+(a-1)*(q1-auc*auc)+(b-1)*(q2-auc*auc))/(a*b);se=np.sqrt(2*var);z=norm.ppf(.975);pw=norm.sf(z-.03/se)+norm.cdf(-z-.03/se);power.append({'assumed_auc':auc,'two_independent_estimates_mde80':float((z+norm.ppf(.8))*se),'power_at_delta_003_independent':float(pw),'assumption':'HanleyMcNeil, independent AUC estimates, approximate normal; no paired covariance claim'})
summary={'unit':189,'people':len(p),'records':len(d),'person_counts':{str(k):int(v) for k,v in p.y.value_counts().items()},'split_counts':{str(k):int(v) for k,v in p.groupby(['split','y']).size().items()},'person_grouping':'any abnormal truth/max-record probability; allmodels same aggregation','win_delta':.03,'power_scenarios_counts_only':power,'lead_order':'I II III aVR aVL aVF V1 V2 V3 V4 V5 V6 from source paper','sample_rate':500,'rate_provenance':'publisher method, HDF5 has no timestamps','length_counts':{str(k):int(v) for k,v in d.N.value_counts().sort_index().items()},'test_sealing':'TEST labels used only for approved aggregate counts; no waveform/value/model reads or outcomescores'};json.dump(summary,open(r+'COUNTS_SPLIT_POWER.json','w'),indent=2);print(json.dumps(summary,indent=2))
