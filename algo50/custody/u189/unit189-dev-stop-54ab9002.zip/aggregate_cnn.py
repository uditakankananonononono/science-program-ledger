import numpy as np,pandas as pd,json,resource,time
from sklearn.metrics import roc_auc_score
r='/tmp/unit189/';d=pd.read_csv(r+'DEV_INDEX.csv');p=d.groupby('Patient_ID').y.max();shuf=pd.Series(np.random.default_rng(1189).permutation(p.to_numpy()),index=p.index)
for perm in [0,1]:
 y=d.Patient_ID.map(shuf).to_numpy() if perm else d.y.to_numpy()
 for lr in [.001,.003]:
  for epochs in [5,10]:
   pred=np.zeros(len(d));cost=[]
   for fold in range(3):
    te=d.fold.to_numpy()==fold;pred[te]=np.load(r+f'cnn-pred-lr{lr}-epochs{epochs}-perm{perm}-fold{fold}.npy');cost.append(json.load(open(r+f'cnn-cost-lr{lr}-epochs{epochs}-perm{perm}-fold{fold}.json')))
   a=pd.DataFrame({'Patient_ID':d.Patient_ID,'pred':pred,'y':y});pp=a.groupby('Patient_ID').agg(pred=('pred','max'),y=('y','max'));name=f'cnn-{lr}-{epochs}';pp.to_csv(r+f'pred-{name}-perm{perm}.csv');s={'name':name,'perm':bool(perm),'person_auc':float(roc_auc_score(pp.y,pp.pred)),'people':len(pp),'cpu_seconds':sum(x['cpu_seconds_sofar'] for x in cost),'peak_rss_MB':max(x['peak_rss_MB'] for x in cost),'costcap_pass':sum(x['cpu_seconds_sofar'] for x in cost)<=3600 and max(x['peak_rss_MB'] for x in cost)<=2048,'parameter_count':5577};json.dump(s,open(r+f'grid-{name}-perm{perm}.json','w'),indent=2);print(s)
