import numpy as np
from scipy.special import expit
class CNN:
 def __init__(self,seed=189):
  rng=np.random.default_rng(seed);self.p={'conv':(rng.normal(size=(8,12,15))*np.sqrt(2/180)).astype('f'),'cb':np.zeros(8,'f'),'w':(rng.normal(size=(256,16))*np.sqrt(2/256)).astype('f'),'b':np.zeros(16,'f'),'out':(rng.normal(size=16)/4).astype('f'),'ob':np.zeros(1,'f')};self.m={k:np.zeros_like(v) for k,v in self.p.items()};self.v={k:np.zeros_like(v) for k,v in self.p.items()};self.step=0
 def calc(self,x,y=None):
  p=self.p;wins=np.lib.stride_tricks.sliding_window_view(x,15,axis=2)[:,:,::5,:];z=np.einsum('bctk,fck->btf',wins,p['conv'],optimize=True)+p['cb'];a=np.maximum(z,0);bins=np.array_split(np.arange(a.shape[1]),32);pool=np.stack([a[:,idx].mean(axis=1) for idx in bins],axis=1);flat=pool.reshape(len(x),256);h=flat@p['w']+p['b'];relu=np.maximum(h,0);logit=relu@p['out']+p['ob'][0];prob=expit(logit)
  if y is None:return prob
  loss=np.mean(np.logaddexp(0,logit)-y*logit);dl=(prob-y)/len(y);gr={'out':relu.T@dl,'ob':np.array([dl.sum()],'f')};dh=dl[:,None]*p['out']*(h>0);gr['w']=flat.T@dh;gr['b']=dh.sum(axis=0);dpool=(dh@p['w'].T).reshape(len(x),32,8);da=np.zeros_like(a)
  for j,idx in enumerate(bins):da[:,idx]=dpool[:,j,None,:]/len(idx)
  dz=da*(z>0);gr['cb']=dz.sum(axis=(0,1));gr['conv']=np.einsum('btf,bctk->fck',dz,wins,optimize=True);return float(loss),gr
 def update(self,g,lr,decay=.001):
  self.step+=1
  for k in self.p:
   grad=g[k]+decay*self.p[k];self.m[k]=.9*self.m[k]+.1*grad;self.v[k]=.999*self.v[k]+.001*grad*grad;self.p[k]-=lr*(self.m[k]/(1-.9**self.step))/(np.sqrt(self.v[k]/(1-.999**self.step))+1e-8)
if __name__=='__main__':
 import json
 rng=np.random.default_rng(1);x=rng.normal(size=(2,12,1000)).astype('f');y=np.array([0,1]);net=CNN();loss,g=net.calc(x,y);out=[]
 for k in net.p:
  index=tuple(0 for _ in net.p[k].shape);old=net.p[k][index].copy();eps=.001;net.p[k][index]=old+eps;up=net.calc(x,y)[0];net.p[k][index]=old-eps;lo=net.calc(x,y)[0];net.p[k][index]=old;num=(up-lo)/(2*eps);ana=float(g[k][index]);error=abs(num-ana);out.append({'parameter':k,'numeric':num,'analytic':ana,'absolute_error':error});assert error<.001
 print(json.dumps({'parameter_count':sum(v.size for v in net.p.values()),'gradientcheck':out},indent=2))
