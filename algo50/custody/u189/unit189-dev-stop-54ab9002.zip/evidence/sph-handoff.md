# SPH integrity handoff - 8 October 2026

Actual raw 2,281,799,680 bytes; MD5 0beef976f54cf0a95fac9f45bb157950 matches Figshare. Filename records.tar.gz is an uncompressed TAR. All 25,770 members join exactly to metadata ECG_ID. All 25,770 HDF5 ecg array shapes equal (12,N), N from metadata. Sampling rate 500 Hz is publisher-method provenance, not independently recoverable from sample HDF5 arrays. Waveforms already machine-filtered; do not call them unfiltered signals.

Source: https://pmc.ncbi.nlm.nih.gov/articles/PMC9174207/
Collection: https://springernature.figshare.com/collections/A_large-scale_multi-label_12-lead_electrocardiogram_database_with_standardized_diagnostic_statements/5779802/1
Raw: https://ndownloader.figshare.com/files/32630684
Metadata: https://ndownloader.figshare.com/files/34793152
Dictionary: https://ndownloader.figshare.com/files/32630954
All exact article APIs report CC0 data license. No root license member is present in raw tar.

Semantic label parser: split AHA_Code by semicolon and normal iff every primary code before + is 1. Two records have duplicated 1;1 and remain normal. Correct record counts: 13,905 normal /11,865 abnormal. Correct people: 13,283 all-normal /11,383 any-abnormal. Keep Patient_ID grouping everywhere; 1,104 records exceed person count. Screen assumes any-abnormal at person level solely to count positive clusters; builder must preregister exact record/person outcome definition without post-outcome switches.

20% hypothetical untouched TEST: 2,276 positive/2,656 negative people. Hanley-McNeil 80%-power two-sided alpha .05 planning at AUC .8 gives .018003 one-estimate MDE/.025460 independent two-estimate MDE; AUC .9 .013086/.018507. These are planning assumptions, not measured AUC and not paired-score power. Record-weight Kish23,661.83 is a clustering diagnostic, not formal power. No splits/models/scores created.

Mean age normal46.884/abnormal53.765; female45.283%/44.127%. Age-sex-bin overlap capacity9,420 per class without choosing people. Hypothetical balanced20% test1,884 per class MDE .028548 independent at AUC .8. Mandatory age-stratified sensitivity remains builder work; balance does not prove absence of confounding. One hospital and machine per paper; dates exist for date-confound scan.

Primary paper proposes normal/abnormal task and patient-aware splitting but no trained classifier benchmark. ECG-Chat (https://arxiv.org/html/2408.08849v1) uses SPH in pretraining but evaluates PTB-XL/CPSC2018, NOT an exact-corpus comparator. Exact-corpus published comparator search remains open. Registry family-proximity ruling pending; not an admission claim.
