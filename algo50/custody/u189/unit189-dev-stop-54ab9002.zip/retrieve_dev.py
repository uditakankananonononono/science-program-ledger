import json,urllib.request,time,os,io,hashlib,h5py,numpy as np
r='/tmp/unit189/';assert json.load(open(r+'raw-stream-verification.json'))['match'];spans=json.load(open(r+'DEV_ONLY_SPANS.json'));os.makedirs(r+'dev_h5',exist_ok=True);p=r+'retrieval-progress.json';state=json.load(open(p)) if os.path.exists(p) else {'next_span':0,'verified_records':0,'bytes':0};start=time.time()
for i in range(state['next_span'],len(spans)):
 run=spans[i];a=run[0]['data_offset'];b=run[-1]['data_end_inclusive'];req=urllib.request.Request('https://ndownloader.figshare.com/files/32630684',headers={'Range':f'bytes={a}-{b}'})
 with urllib.request.urlopen(req,timeout=15) as resp:
  assert resp.status==206 and resp.headers.get('Content-Range')==f'bytes {a}-{b}/2281799680';data=resp.read();assert len(data)==b-a+1
 for m in run:
  payload=data[m['data_offset']-a:m['data_end_inclusive']-a+1];name=m['path'].split('/')[-1]
  with h5py.File(io.BytesIO(payload),'r') as h:
   v=h['ecg'][:];assert v.ndim==2 and v.shape[0]==12 and np.isfinite(v).all();shape=list(v.shape);dtype=str(v.dtype)
  path=r+'dev_h5/'+name
  if os.path.exists(path):assert hashlib.sha256(open(path,'rb').read()).digest()==hashlib.sha256(payload).digest()
  else:
   with open(path+'.tmp','wb') as w:w.write(payload)
   os.replace(path+'.tmp',path)
  with open(r+'DEV_H5_VERIFICATION.jsonl','a') as w:w.write(json.dumps({'record':name[:-3],'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'shape':shape,'dtype':dtype,'source_archive_publisher_md5_verified':True})+'\n')
 state.update(next_span=i+1,verified_records=state['verified_records']+len(run),bytes=state['bytes']+len(data));json.dump(state,open(p,'w'));print('SPAN',i+1,'/',len(spans),'DEVrecords',state['verified_records'],flush=True);time.sleep(2)
 if time.time()-start>45:break
