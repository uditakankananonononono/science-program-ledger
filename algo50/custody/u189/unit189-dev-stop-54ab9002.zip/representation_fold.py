import pandas as pd,numpy as np,json,os,time,sys
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
r='/tmp/unit189/';fold=int(sys.argv[1]);d=pd.read_csv(r+'DEV_INDEX.csv');tr=d.fold.to_numpy()!=fold;rng=np.random.default_rng(189);pool=[]
# Label-free deterministic training-beat reservoir, max50000. Random sampling from training only.
for i in rng.permutation(np.flatnonzero(tr)):
 with np.load(r+'feature_cache/'+d.ECG_ID.iloc[i]+'.npz') as x:
  beats=x['beats']
  if len(beats)>=2:pool.extend(beats)
 if len(pool)>=50000:break
pool=np.array(pool[:50000]);pca=PCA(n_components=16,random_state=189);z=pca.fit_transform(pool);stats=np.zeros((len(d),80),'f');projections=[]
for row in d.itertuples():
 with np.load(r+'feature_cache/'+row.ECG_ID+'.npz') as x:b=x['beats'];zz=pca.transform(b) if len(b)>=2 else np.zeros((1,16),'f');projections.append(zz)
for i,zr in enumerate(projections):stats[i]=np.r_[zr.mean(0),zr.std(0),np.percentile(zr,10,axis=0),np.percentile(zr,50,axis=0),np.percentile(zr,90,axis=0)]
np.save(r+f'beatstats-fold{fold}.npy',stats)
for k in [8,16]:
 km=KMeans(n_clusters=k,random_state=189,n_init=1,max_iter=100).fit(z);dist=np.linalg.norm(z[:1000,None,:]-km.cluster_centers_[None,:,:],axis=2);bw=np.median(dist);out=np.zeros((len(d),k),'f');
 for scale in [1,2]:
  for i,zr in enumerate(projections):dd=np.linalg.norm(zr[:,None,:]-km.cluster_centers_[None,:,:],axis=2);out[i]=np.exp(-dd*dd/(2*(scale*bw)**2)).mean(0)
  np.save(r+f'dist-fold{fold}-k{k}-bw{scale}.npy',out)
 np.savez(r+f'prototypes-fold{fold}-k{k}.npz',centers=km.cluster_centers_,bandwidth=bw,pca_mean=pca.mean_,pca_components=pca.components_)
print('REPRESENTATION',fold,'trainbeats',len(pool),flush=True)
