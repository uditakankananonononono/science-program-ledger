import os,json,numpy as np,pandas as pd,h5py,time
from scipy.signal import butter,sosfiltfilt,resample_poly,welch,find_peaks
from scipy.stats import skew,kurtosis
r='/tmp/unit189/';d=pd.read_csv(r+'DEV_RECORDS.csv');os.makedirs(r+'feature_cache',exist_ok=True)
def pan_tompkins(x,fs=500):
 bp=sosfiltfilt(butter(2,[5,15],btype='bandpass',fs=fs,output='sos'),x);der=np.convolve(bp,np.array([1,2,0,-2,-1])/8,mode='same');integ=np.convolve(der*der,np.ones(75)/75,mode='same');peaks,_=find_peaks(integ,distance=100);init=integ[:1000];sp=float(np.max(init)*.25);noise=float(np.mean(init)*.5);selected=[];rejected=[]
 for p in peaks:
  threshold=noise+.25*(sp-noise)
  if integ[p]>=threshold:
   selected.append(int(p));sp=.125*integ[p]+.875*sp
  else:rejected.append(int(p));noise=.125*integ[p]+.875*noise
  if len(selected)>=2:
   rr=np.median(np.diff(selected[-9:]));last=selected[-1]
   if p-last>1.66*rr:
    candidates=[q for q in rejected if last+100<q<=p-100 and integ[q]>threshold*.5]
    if candidates:
     q=max(candidates,key=lambda q:integ[q]);selected.append(q);selected.sort();sp=.25*integ[q]+.75*sp
 out=[]
 for p in selected:
  lo=max(0,p-75);hi=min(len(x),p+76);q=lo+int(np.argmax(np.abs(bp[lo:hi])))
  if not out or q-out[-1]>=100:out.append(q)
 return np.array(out,dtype=int)
start=time.time();n=0
for row in d.itertuples():
 out=r+'feature_cache/'+row.ECG_ID+'.npz';p=r+'dev_h5/'+row.ECG_ID+'.h5'
 if os.path.exists(out) or not os.path.exists(p):continue
 with h5py.File(p,'r') as h:x=h['ecg'][:,:5000].astype(np.float32)
 assert x.shape==(12,5000) and np.isfinite(x).all();f,pow=welch(x,fs=500,nperseg=1024,axis=1);den=pow[:,(f>=.5)&(f<=40)].sum(axis=1)+1e-12
 stats=[np.mean(x,axis=1),np.std(x,axis=1),skew(x,axis=1),kurtosis(x,axis=1),np.min(x,axis=1),np.max(x,axis=1),np.sqrt(np.mean(x*x,axis=1)),np.std(np.diff(x,axis=1),axis=1)]+[pow[:,(f>=a)&(f<b)].sum(axis=1)/den for a,b in [(.5,5),(5,15),(15,40)]]+[np.mean(np.abs(np.diff(x,axis=1)),axis=1)];globalf=np.stack(stats,axis=1).flatten();globalf=np.nan_to_num(globalf)
 peaks=pan_tompkins(x[1]);valid=peaks[(peaks>=100)&(peaks+200<=5000)];rr=np.diff(peaks)/500;rrsum=np.array([np.median(rr) if len(rr) else 0,np.subtract(*np.percentile(rr,[75,25])) if len(rr) else 0,np.sqrt(np.mean(np.diff(rr)**2)) if len(rr)>1 else 0,len(valid)],dtype=np.float32)
 if len(valid)>32:valid=valid[np.linspace(0,len(valid)-1,32).astype(int)]
 beats=[]
 for p in valid:
  b=resample_poly(x[:,p-100:p+200],1,5,axis=1);b=b-b[:,:10].mean(axis=1,keepdims=True);beats.append(b.flatten())
 beats=np.array(beats,dtype=np.float32).reshape(-1,720);wave=resample_poly(x,1,5,axis=1).astype(np.float16);np.savez_compressed(out,globalf=globalf.astype(np.float32),rr=rrsum,beats=beats,wave=wave)
 n+=1
 if n%100==0:print('FEATURES',n,'time',round(time.time()-start,1),flush=True)
 if time.time()-start>50:break
print('CACHEtotal',len(os.listdir(r+'feature_cache')),'new',n,flush=True)
