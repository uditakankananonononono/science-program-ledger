import pandas as pd,numpy as np,json
r='/tmp/unit189/';models=['gbmmatched-15-1','local-16-1-1'];p=[pd.read_csv(r+f'pred-{m}-perm0.csv').sort_values('Patient_ID') for m in models];assert (p[0].Patient_ID.to_numpy()==p[1].Patient_ID.to_numpy()).all();n=len(p[0]);y=p[0].y.to_numpy();prep=[]
for d in p:
 order=np.argsort(d.pred.to_numpy(),kind='stable');s=d.pred.to_numpy()[order];cuts=np.r_[0,np.flatnonzero(np.diff(s)!=0)+1];prep.append((order,cuts))
rng=np.random.default_rng(189);a=[]
for b in range(2000):
 w=np.bincount(rng.integers(0,n,n),minlength=n);au=[]
 for order,cuts in prep:
  yy=y[order];ww=w[order];pos=np.add.reduceat(ww*yy,cuts);neg=np.add.reduceat(ww*(1-yy),cuts);au.append(float((pos*(np.cumsum(neg)-neg+.5*neg)).sum()/(pos.sum()*neg.sum())))
 a.append([au[0],au[1],au[1]-au[0]])
ci=np.percentile(a,[2.5,97.5],axis=0);out={'unit':189,'status':'REJECTED_DEV_CANDIDATE_FEASIBILITY_NO_PREREG_NO_TEST','bootstrap_unit':'Patient_ID','reps':2000,'seed':189,'matched_gbm_dev_auc':.9209292671661994,'matched_gbm_dev_ci':ci[:,0].tolist(),'candidate_dev_auc':.8588823269600081,'candidate_dev_ci':ci[:,1].tolist(),'candidate_minus_gbm_dev':-.06204694020619128,'paired_dev_ci':ci[:,2].tolist(),'caveat':'Exploratory DEV-selected models, CI does not adjust for selection or full pipeline refits; not TEST validation.','test_ids_scored_or_inspected':False};json.dump(out,open(r+'RESULT.json','w'),indent=2);print(json.dumps(out,indent=2))
