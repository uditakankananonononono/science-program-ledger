import json,urllib.request,time,os,io,hashlib,h5py,numpy as np,pandas as pd
r='/tmp/unit189/';assert json.load(open(r+'raw-stream-verification.json'))['match'];d=pd.read_csv(r+'DEV_RECORDS.csv');ids=set(d.ECG_ID);m=[x for x in json.load(open(r+'evidence/sph-tar-range-manifest.json')) if x['path'].split('/')[-1][:-3] in ids];os.makedirs(r+'dev_h5',exist_ok=True);p=r+'serial-retrieval-progress.json';state=json.load(open(p)) if os.path.exists(p) else {'next_byte':0,'total_bytes':2281799680,'policy':'TEST member bytes are transport-only - never parsed, never written to disk or any cache, discarded in-memory at the header/offset level; only DEV member payloads are extracted and persisted.'};start=time.time();off=state['next_byte']
while off<state['total_bytes'] and time.time()-start<45:
 end=min(off+32*1024*1024,state['total_bytes'])-1;req=urllib.request.Request('https://ndownloader.figshare.com/files/32630684',headers={'Range':f'bytes={off}-{end}'})
 with urllib.request.urlopen(req,timeout=15) as resp:
  assert resp.status==206 and resp.headers.get('Content-Range')==f"bytes {off}-{end}/{state['total_bytes']}";data=resp.read();assert len(data)==end-off+1
 for f in m:
  a=f['data_offset'];b=f['data_end_inclusive'];name=f['path'].split('/')[-1];out=r+'dev_h5/'+name
  if b<off or a>end or os.path.exists(out):continue
  s=max(a,off);e=min(b,end);part=out+'.part'
  with open(part,'r+b' if os.path.exists(part) else 'w+b') as w:w.seek(s-a);w.write(data[s-off:e-off+1])
  if e==b:
   assert os.path.getsize(part)==f['size']
   with h5py.File(part,'r') as h:
    v=h['ecg'][:];assert v.ndim==2 and v.shape[0]==12 and np.isfinite(v).all();shape=list(v.shape);dtype=str(v.dtype)
   sha=hashlib.sha256(open(part,'rb').read()).hexdigest();os.replace(part,out)
   with open(r+'DEV_H5_VERIFICATION.jsonl','a') as w:w.write(json.dumps({'record':name[:-3],'bytes':f['size'],'sha256':sha,'shape':shape,'dtype':dtype,'source_archive_publisher_md5_verified':True})+'\n')
 off=end+1;state['next_byte']=off;state['cached_dev_records']=len([n for n in os.listdir(r+'dev_h5') if n.endswith('.h5')]);json.dump(state,open(p,'w'));print(off,'/',state['total_bytes'],'DEVcached',state['cached_dev_records'],flush=True);time.sleep(2)
