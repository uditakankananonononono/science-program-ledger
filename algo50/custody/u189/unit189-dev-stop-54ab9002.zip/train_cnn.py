import os,json,pickle,time,resource,sys,numpy as np,pandas as pd
from numpy_cnn import CNN
from sklearn.metrics import roc_auc_score
r='/tmp/unit189/';perm=int(sys.argv[1]);lr=float(sys.argv[2]);fold=int(sys.argv[3]);d=pd.read_csv(r+'DEV_INDEX.csv');waves=np.load(r+'waves.npy',mmap_mode='r');tr=np.flatnonzero(d.fold.to_numpy()!=fold);te=np.flatnonzero(d.fold.to_numpy()==fold);people=d.groupby('Patient_ID').y.max();rng=np.random.default_rng(1189);shuf=pd.Series(rng.permutation(people.to_numpy()),index=people.index);y=d.Patient_ID.map(shuf).to_numpy() if perm else d.y.to_numpy();p=r+f'cnn-lr{lr}-perm{perm}-fold{fold}.pkl';start=time.time();cpu=time.process_time()
if os.path.exists(p):s=pickle.load(open(p,'rb'))
else:
 # training-only perlead mean/std in streamingchunks
 sums=np.zeros(12);squares=np.zeros(12);n=0
 for a in np.array_split(tr,100):
  x=waves[a].astype('f');sums+=x.sum(axis=(0,2));squares+=(x*x).sum(axis=(0,2));n+=len(a)*1000
 mean=sums/n;std=np.sqrt(np.maximum(squares/n-mean*mean,1e-8));s={'net':CNN(),'epoch':0,'batch':0,'mean':mean.astype('f'),'std':std.astype('f'),'cpu_seconds':0,'wall_seconds':0,'fold':fold,'lr':lr,'perm':perm}
while s['epoch']<10 and time.time()-start<45:
 order=np.random.default_rng(189+s['epoch']).permutation(tr)
 for b in range(s['batch'],len(order),16):
  a=order[b:b+16];x=waves[a].astype('f');x=(x-s['mean'][None,:,None])/s['std'][None,:,None];loss,g=s['net'].calc(x,y[a]);s['net'].update(g,lr);s['batch']=b+16
  if time.time()-start>45:break
 if s['batch']>=len(order):
  s['epoch']+=1;s['batch']=0;print('CNN',perm,lr,fold,'EPOCH',s['epoch'],flush=True)
  if s['epoch'] in [5,10]:
   pr=np.zeros(len(te))
   for i in range(0,len(te),16):
    a=te[i:i+16];x=(waves[a].astype('f')-s['mean'][None,:,None])/s['std'][None,:,None];pr[i:i+len(a)]=s['net'].calc(x)
   np.save(r+f'cnn-pred-lr{lr}-epochs{s["epoch"]}-perm{perm}-fold{fold}.npy',pr)
   json.dump({'cpu_seconds_sofar':s['cpu_seconds']+time.process_time()-cpu,'wall_seconds_sofar':s['wall_seconds']+time.time()-start,'peak_rss_MB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,'trained_parameters':5577,'epoch':s['epoch'],'fold':fold},open(r+f'cnn-cost-lr{lr}-epochs{s["epoch"]}-perm{perm}-fold{fold}.json','w'))
s['cpu_seconds']+=time.process_time()-cpu;s['wall_seconds']+=time.time()-start;tmp=p+'.tmp';pickle.dump(s,open(tmp,'wb'));os.replace(tmp,p);print('CHECKPOINT',perm,lr,fold,'epoch',s['epoch'],'batch',s['batch'],'cpu',s['cpu_seconds'],flush=True)
