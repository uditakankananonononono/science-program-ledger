import pandas as pd,numpy as np,json,glob,os,time
r='/tmp/unit189/';start=time.time()
for p in glob.glob(r+'pred-*-perm1.csv'):
 name=os.path.basename(p)[5:-10];out=r+'perm-ci-'+os.path.basename(p)[:-4]+'.json'
 if os.path.exists(out):continue
 d=pd.read_csv(p).sort_values('Patient_ID');order=np.argsort(d.pred.to_numpy(),kind='stable');score=d.pred.to_numpy()[order];y=d.y.to_numpy()[order];n=len(y);cuts=np.r_[np.flatnonzero(np.diff(score)!=0)+1,n];beg=np.r_[0,cuts[:-1]];rng=np.random.default_rng(189);au=[]
 for b in range(2000):
  w=np.bincount(rng.integers(0,n,n),minlength=n);pos=np.add.reduceat(w*y,beg);neg=np.add.reduceat(w*(1-y),beg);totp=pos.sum();totn=neg.sum()
  if totp and totn:au.append(float((pos*(np.cumsum(neg)-neg+.5*neg)).sum()/(totp*totn)))
 ci=np.percentile(au,[2.5,97.5]).tolist();s={'prediction_file':os.path.basename(p),'permutation_seed':1189,'bootstrap_seed':189,'reps':2000,'unit':'Patient_ID','ci':ci,'covers_chance':ci[0]<=.5<=ci[1]};json.dump(s,open(out,'w'),indent=2);print(s,flush=True)
 if time.time()-start>55:break
