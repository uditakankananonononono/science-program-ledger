import json, os, platform, time, resource
import torch
from transformers import AutoTokenizer, AutoModel
MODEL=os.path.join(os.path.dirname(__file__),'..','inputs')
seqs=[
 'ACDEFGHIKLMNPQRSTVWY'*3,
 'MKTIIALSYIFCLVFADYKDDDDK' * 5,
 'G'*256,
 'ACDEFGHIKLMNPQRSTVWY'*25,
]
tok=AutoTokenizer.from_pretrained(MODEL, local_files_only=True)
model=AutoModel.from_pretrained(MODEL, local_files_only=True).eval()
rows=[]
with torch.inference_mode():
 for s in seqs:
  x=tok(s,return_tensors='pt',truncation=True,max_length=1024)
  t=time.perf_counter(); y=model(**x).last_hidden_state; elapsed=time.perf_counter()-t
  pooled=y[:,1:-1].mean(1)
  rows.append({'residues':len(s),'tokens':int(x['input_ids'].shape[1]),'seconds':elapsed,'embedding_shape':list(pooled.shape),'rss_mb':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024})
out={'phase':'metadata/compute pilot only; synthetic sequences; no dataset records or labels read','python':platform.python_version(),'torch':torch.__version__,'cpu_threads':torch.get_num_threads(),'cuda':torch.cuda.is_available(),'model_config':{'hidden_size':model.config.hidden_size,'layers':model.config.num_hidden_layers,'params':sum(p.numel() for p in model.parameters())},'rows':rows}
print(json.dumps(out,indent=2))
