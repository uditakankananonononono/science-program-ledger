# DOC-2-009 R1 prospective lock v2

Status: **AMENDED, PROPOSED, UNEXECUTED - DO NOT ACCESS ARCHIVE MEMBERS OR RUN OUTCOMES UNTIL ADJUDICATED AND DUAL-SEALED**  
Supersedes proposed v1 SHA-256 `f70f46e3809d829ed6b94032755325fe7416a449666426da4763b43e335e9383`, which remains preserved as unexecuted. The amendment is prospective: no TAPE JSON member has been extracted or read; no sequence, label, prediction, or outcome has been inspected.

## 1. Scientific lineage and claim boundary

This is a **new remote-homology classification domain-shift mechanism study** of manifold-distance selective abstention. It is not a direct validation of R0's mutation-effect or deep-mutational-scanning (DMS) reliability endpoint. Even a positive result here cannot rescue, graduate, or generalize the R0 DMS claim. Any DMS claim requires a later, separately locked and adjudicated DMS validation.

Question: under the official TAPE remote-homology distribution shifts, does distance from a frozen pretrained-residue-embedding training manifold identify unreliable fold-class predictions and support useful abstention?

H1: on the primary official TAPE `test_family_holdout` file, an abstention score derived only from frozen ESM-2 embeddings and training-manifold distance will enrich errors and outperform confidence abstention at useful coverage. H0 includes null, harmful, infeasible, or comparator-inferior abstention. Negative results are retained.

## 2. Inputs and exact source pins

### TAPE remote homology

- Raw archive: http://s3.amazonaws.com/songlabdata/proteindata/data_raw_pytorch/remote_homology.tar.gz
- SHA-256: `49b8917730adabca8fb33878cd6cbe433f95ba9c22ccc06834a0171021c44b61`
- Official code/documentation: https://github.com/songlab-cal/tape at commit `6d345c2b2bbf52cd32cf179325c222afd92aec7e`
- Primary paper: Rao et al., TAPE, https://doi.org/10.48550/arxiv.1906.08230 and https://pmc.ncbi.nlm.nih.gov/articles/PMC7774645/
- Underlying task data: Hou et al. / SCOP 1.75, cited by TAPE; SCOPe context: https://scop.berkeley.edu/
- Archive directory metadata, without extraction, confirms official files: `train`, `valid`, `test_family_holdout`, `test_superfamily_holdout`, `test_fold_holdout`.

**Official split semantics only:** TAPE defines 1,195 fold labels and says the Hou et al. data are hierarchically classified protein domains. TAPE reports the three official test datasets as constructed by Hou et al.; `Fold` is the most distant from train, with `Superfamily` and `Family` increasingly related/easier. TAPE Appendix A.1.3 says all proteins in a fold are categorized into related superfamilies and that entire superfamilies are held out from training. This study uses the official filenames and those published semantics. It does **not** claim InterPro connected components, infer connected components, or rename any split as a component holdout.

TAPE asks users to cite all source components. Raw records will not be redistributed. If adjudication finds source-license terms insufficient for the intended artifact publication, execution stops before archive extraction.

### Frozen embedding model

`facebook/esm2_t6_8M_UR50D`, MIT-tagged, Hugging Face revision `c731040fcd8d73dceaa04b0a8e6329b345b0f5df`: https://huggingface.co/facebook/esm2_t6_8M_UR50D

- `model.safetensors`: `24c5fa474c48f3b754b86efe752d5f189d2bcd88190fa2270fc92b2ef3034189`
- `config.json`: `facb9355e8252149f6f99dff5fd1e32e890c3c655362b261d0c81cd6b5839c85`
- `vocab.txt`: `0b82cc0a7c7cf9e567b1e5892d793285b9fbae822c964ca48696f7db44598e03`
- `tokenizer_config.json`: `7e9161ecdb548ec45a41cbc6b24aa4476fdd418461f491c4207baa99419a29ad`
- `special_tokens_map.json`: `3aedcd4211c0d43aec4e607ff60a63255f3174ead795e997350f09a5f8cd9ee1`

## 3. Population, parser, duplicates, class mapping

After adjudication and dual seal only, parse every record in all five official files. No label-, length-, class-frequency-, or performance-based exclusion. Required fields are a nonempty amino-acid string in `primary` and an integer-like `fold_label`. Rejecting a malformed record is an embedding failure, not row removal from denominators.

Within a file, exact duplicate sequences are collapsed by first archive-order occurrence solely for fitting/evaluation, with all duplicate counts and labels in `dedup_audit.csv`. Conflicting labels for an exact sequence are a hard integrity failure. Cross-file exact duplicates are never removed; any cross-file duplicate is integrity failure I2 and stops scientific claims.

Class mapping is the lexicographically sorted unique normalized `fold_label` values in train, assigned contiguous indices 0..K-1. Write canonical strict JSON `class_index.json` and SHA-256. Report total records, valid records, unique labels, absent-train labels, and per-label counts for every split. Train classes absent from validation/test remain in the classifier with no special handling. Validation/test labels unseen in train are always incorrect, never excluded, and receive model uncertainty from the train-class softmax; they remain in every denominator. If validation contains an unseen label, it also participates in the combined-score error target.

## 4. Official splits

- Fit only: `train`.
- Threshold/combined-score fit only: `valid`.
- Primary locked test: `test_family_holdout`.
- Secondary non-rescue tests: `test_superfamily_holdout`, then `test_fold_holdout`.
- Never pool or reassign official records.

## 5. Frozen residue representation and overlap correction

Model is eval/inference-only; no finetuning. Use final hidden-layer residue embeddings; never use a newly initialized pooler. Exclude BOS/EOS. Store float32 embeddings.

- Length <=1022: one complete pass; arithmetic mean over all residue embeddings.
- Length >1022: windows of 1022 residues, stride 511, plus one final right-aligned window if not already present. Maintain an accumulator and count for every original residue. For each window, add that window's embedding for residue i to accumulator[i] and increment count[i]. Divide each residue accumulator by its count, then average the resulting residue vectors exactly once over the original sequence. This removes overlap double-counting.

The pre-outcome synthetic fixture uses deterministic synthetic residue vectors, not TAPE data. It must pass: for lengths <=1022, exact one-window equality to direct mean; for lengths 1023, 1533, 2048, 2500, all positions have count >=1 and overlap-corrected pooled vectors equal the direct synthetic residue mean to absolute tolerance 1e-12. Fixture script/result hashes are pre-outcome artifacts.

## 6. Locked predictor and scores

Fit on train embeddings only:

1. Standardize 320 dimensions with train mean and population SD (`ddof=0`); zero-SD dimensions map to zero.
2. PCA: `n_components=min(64, n_train-1, nonzero_SD_dimensions)`, `svd_solver="full"`, seed 1701.
3. Multinomial logistic regression: L2, C=1.0, `solver="lbfgs"`, max_iter=5000, tol=1e-6, class_weight=None, seed 1701. No search or fallback. Nonconvergence fails I4.
4. Distance: squared Mahalanobis distance in PCA space using `LedoitWolf(assume_centered=False)` fitted on train PCA scores. Higher is farther.
5. Confidence comparator: `1-max(train-class softmax probability)`. Higher is less confident.
6. Combined score, secondary only: validation-fit logistic regression predicting binary error from validation-z-scored distance and uncertainty, no penalty, fixed solver/max_iter/tol as above. If unsupported/nonconvergent, report unavailable; it cannot affect primary verdict.

Nonfinite/missing embedding: set distance and uncertainty to `+infinity`. Such a record always sorts last and never passes the finite validation threshold. It counts wrong at full coverage. It is excluded only from Spearman because distance is undefined; report Spearman numerator n and full estimand denominator N. I3 limits this exception.

## 7. Threshold, retained denominator, and risk-coverage mechanics

Distance threshold is validation's empirical 80th percentile among finite distances using NumPy `quantile(..., 0.80, method="higher")`. If no finite validation score exists, I3 fails. A record is retained iff finite distance <= this unchanged numeric threshold.

Fixed-threshold retained accuracy denominator is exactly the number of retained records; numerator is correct retained predictions. Report retained count, total official post-dedup count, missing count, and coverage `retained/total`. If retained count is zero, retained accuracy is null and I5/P2 fail.

Risk-coverage uses fixed coverages `C={0.10,0.20,...,1.00}`. For N post-dedup records and each c, set `k=max(1, ceil(c*N))`; stable-sort ascending score, with archive order breaking ties, retain first k, and compute risk as wrong/k. Thus no point has fewer than one record; actual coverage k/N is reported. Missing `+infinity` records enter only at the end, archive-order tied. **AURC is the simple arithmetic mean of the ten risks**, `AURC=(1/10)*sum_{c in C} risk(c)`. No trapezoid or endpoint extrapolation. Distance and confidence use identical k, tie, missing, and averaging mechanics.

## 8. Bootstrap and uncertainty

The archive is still unopened, so availability of identifiers finer than `fold_label` is unknown. Freeze this decision tree:

1. At first parse, write schema keys and missingness to `schema_audit.json` before modeling. If a stable official family/group identifier exists in every record of the evaluated split, define clusters by that exact field and resample clusters with replacement; include all records of sampled clusters, preserving duplicate sampled clusters as repeated blocks.
2. Otherwise use **fold-label-stratified record resampling**: within each observed normalized fold label, sample n_label records with replacement and concatenate strata, preserving each split's label counts. This limitation must be explicit: fold label is not a finer family ID, so uncertainty may remain optimistic for within-label family dependence.
3. Fail closed for inferential gates unless the primary split has >=20 represented fold labels, >=10 labels with at least 2 records, and both correct and incorrect records overall. If not, bootstrap CIs are unavailable and P1 fails; point estimates remain descriptive.

Run 2,000 paired bootstrap replicates, seed 1701. In each replicate, carry paired prediction, correctness, distance, and uncertainty rows through identical calculations. Compute percentile 95% CIs for Spearman rho (finite distances only), fixed-threshold accuracy delta, and paired `AURC_distance-AURC_confidence`.

CI rules: P1 requires rho point estimate >=0.10 **and** rho CI lower bound >0. P2 uses point estimate >=0.030; its paired CI is report-only. P3 uses point estimate `AURC_distance <=0.95*AURC_confidence`; the paired AURC-difference CI is report-only. No secondary metric or CI rescues a failed primary gate.

## 9. Gates and verdict

Integrity, all required:

- I1 all input/model/source hashes match.
- I2 no conflicting within-file duplicate and no cross-file exact-sequence duplicate.
- I3 >=95% of total records in every split produce finite embeddings.
- I4 locked classifier converges without fallback.
- I5 primary fixed-threshold coverage is 60%-95% inclusive and retained n>0.
- I6 class mapping, schema audit, split/per-class counts, failure-injection tests, environment seal, provenance, runtime/RSS logs, and dual-seal readbacks all validate.

Primary success on `test_family_holdout`, all required:

- P1 finite-score Spearman(distance, error) >=0.10 with 2,000-bootstrap 95% CI lower bound >0.
- P2 fixed-threshold retained accuracy minus full-coverage accuracy >=0.030.
- P3 distance AURC <=0.95 times confidence-comparator AURC.

All pass = positive remote-homology abstention mechanism result within this task. Any fail = locked negative/boundary result. Neither verdict changes the R0 DMS claim.

Secondary non-rescue outputs: same point metrics/CIs on superfamily and fold tests; distance deciles; full/retained accuracy and macro-F1; descriptive per-class retained coverage for labels with >=20 records; one within-split distance permutation with seed 1701.

## 10. Environment, strict serialization, provenance, and resource logs

Frozen environment: Linux x86_64, Python 3.10.12, CPU-only, one Torch thread; `torch==2.14.0`, `transformers==5.17.0`, `safetensors==0.8.0`, `numpy==2.2.6`, `pandas==2.3.3`, `scipy==1.15.3`, `scikit-learn==1.7.2`. The full v2 `pip freeze` is sealed. Any substitution requires a prospective v3 amendment.

Set Python hash seed, Python/NumPy/Torch seeds to 1701, Torch deterministic algorithms on, and thread counts to 1. Record UTC start/end, wall seconds, per-stage seconds, peak RSS bytes (`resource.getrusage` plus `/usr/bin/time -v`), CPU model, OS/kernel, command line, git/script SHA, input hashes, package freeze SHA, seeds, and model revision in `provenance.json` and `runtime.json`.

Every JSON artifact must be RFC 8259 strict: UTF-8, sorted keys, no NaN/Infinity tokens (`allow_nan=False`); encode missing/nonfinite values as null plus an explicit status/reason field. CSVs use UTF-8, LF, fixed column order, and empty cell for missing numeric values.

## 11. Pre-run failure injections

Before real records are parsed/modelled, run synthetic fixtures that must fail or pass as expected:

- corrupt one byte of a copied pinned file -> hash verification must fail;
- malformed JSON, missing `primary`, non-string/empty sequence, missing/non-integer-like label -> parser must mark failure without silent row loss;
- same sequence/same label within split -> deterministic first-occurrence dedup audit;
- same sequence/conflicting labels within split -> hard fail;
- cross-split duplicate -> I2 hard fail;
- unseen validation/test label -> mapped as unseen and scored wrong, retained in denominators;
- missing embedding -> +infinity sorting behavior, excluded only from Spearman;
- tied scores -> archive-order stable tie break;
- strict JSON serialization rejects NaN/Infinity;
- overlap-corrected pooling fixture described above.

Write `failure_injection.json`; any mismatch fails I6 before biological outcomes.

## 12. Dual seal, outputs, and stop rule

Before archive-member access, the adjudicated lock, pre-outcome hash manifest, environment freeze, synthetic pilot, and fixtures must be saved to **two durable program stores**: the science-program GitHub repository and program Google Drive. Read both copies back through their source APIs, hash the bytes, and require equality to the adjudicated local hashes. Record real repository commit/blob URL and Drive file URL/ID plus readback hashes in `dual_seal_receipt.json`. A local path, proposed upload, or one-store upload is insufficient. Execution starts only after orchestrator approval and successful dual readback.

Outcome outputs: `schema_audit.json`, `class_index.json`, `manifest.json`, `dedup_audit.csv`, `embedding_failures.csv`, `split_class_counts.csv`, `metrics.json`, `risk_coverage.csv`, `deciles.csv`, `bootstrap.csv`, `failure_injection.json`, `verdict.json`, run script/config, stdout/stderr, environment freeze, provenance/runtime/RSS logs, dual-seal receipt, and `SHA256SUMS`.

Run once. Hash every output immediately before inspection or summary. Do not tune, rerun, chart, or add analyses after outcomes. Any follow-up is a separately adjudicated R2.
