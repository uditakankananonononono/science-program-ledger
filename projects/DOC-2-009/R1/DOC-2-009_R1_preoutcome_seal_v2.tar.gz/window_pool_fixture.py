"""Synthetic, model-free fixture for locked overlap correction. No TAPE member access."""
import json, hashlib
import numpy as np

def starts(L, window=1022, stride=511):
    if L <= window: return [0]
    s=list(range(0, L-window+1, stride))
    last=L-window
    if s[-1] != last: s.append(last)
    return s

def corrected_pool(residue_vectors, window=1022, stride=511):
    L,D=residue_vectors.shape
    acc=np.zeros((L,D),dtype=np.float64); cnt=np.zeros(L,dtype=np.int64)
    for s in starts(L,window,stride):
        e=min(s+window,L); acc[s:e]+=residue_vectors[s:e]; cnt[s:e]+=1
    return (acc/cnt[:,None]).mean(0),cnt
rng=np.random.default_rng(1701)
rows=[]
for L in [1,60,1022,1023,1533,2048,2500]:
    x=rng.normal(size=(L,7))
    pooled,cnt=corrected_pool(x)
    direct=x.mean(0)
    rows.append({'length':L,'starts':starts(L),'min_coverage':int(cnt.min()),'max_coverage':int(cnt.max()),'all_residues_covered':bool(np.all(cnt>=1)),'max_abs_diff_from_direct_mean':float(np.max(np.abs(pooled-direct))),'equal_within_1e-12':bool(np.allclose(pooled,direct,rtol=0,atol=1e-12))})
out={'fixture':'overlap-corrected synthetic residue pooling','seed':1701,'rows':rows}
print(json.dumps(out,sort_keys=True,indent=2,allow_nan=False))
