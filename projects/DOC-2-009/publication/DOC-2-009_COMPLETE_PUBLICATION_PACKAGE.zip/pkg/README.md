# DOC-2-009 complete publication package

## Outcome
Locked R0 verdict: **NO-GO**. The outcome text in the accepted research paper has not been altered. This package preserves the negative result, exact evidence, reproducible analysis, and a separate 21-page technical report.

## Read first
- Research paper: `paper/DOC-2-009_FULL_PAPER.pdf`
- Full technical report: `technical_report/DOC-2-009_TECHNICAL_REPORT.pdf`
- Frozen protocol: `evidence/LOCKED_PROTOCOL.md`
- Machine result: `evidence/results.json`
- Complete predictions: `evidence/oof_predictions.csv`
- Source ledger: `provenance/SOURCE_ACQUISITION_LEDGER.md`
- File manifest: `manifests/FILE_MANIFEST.tsv`
- Hash manifest: `manifests/MANIFEST.sha256`

## Claim-to-evidence map
| Paper claim | Evidence path | SHA-256 |
|---|---|---|
| Protocol and gates were frozen before outcome analysis | `evidence/LOCKED_PROTOCOL.md` | `66777cb32f7f181d174a2625b09ec32ab6bcabf13233880f950580c55073bf27` |
| 217 assays, 186 proteins, 163 annotated, 102 components | `evidence/results.json` | `ba4646679ed3d1d7334dbd005b5892a1e1941eb335bb2b865d01aa84b49276d0` |
| rho 0.1198; R2 -0.2235; MAE 0.1804 vs 0.1705 | `evidence/results.json` | `ba4646679ed3d1d7334dbd005b5892a1e1941eb335bb2b865d01aa84b49276d0` |
| rho 95% interval -0.0378 to 0.2750 | `evidence/results.json`, `evidence/run_r0.py` | `ba464...76d0`, `89ec0e...2c3d` |
| Zero family-component overlap in every fold | `evidence/results.json` (`folds[].group_overlap`) | `ba4646679ed3d1d7334dbd005b5892a1e1941eb335bb2b865d01aa84b49276d0` |
| Every protein has one frozen OOF prediction | `evidence/oof_predictions.csv` | `662430013cc0d0ef6e6f458810ed7a3cbb46c5112b6de54672c9cc84eacd0eec` |
| Human/eukaryote/prokaryote non-positive; virus exploratory positive | `evidence/results.json`, `evidence/oof_predictions.csv` | hashes above |
| ProteinGym reference identity and contents | `provenance/DMS_substitutions.csv` | `a8f498011532a74aa9fe556a50555a75e928c5837d19c06a87592ae04049b308` |
| Official ESM2-650M assay outcomes | `provenance/DMS_substitutions_Spearman_DMS_level.csv` | `f432423b87f79ac9778dfac86e3d95be041d246bc618dc0a406b35b0b7466437` |
| InterPro family cross-references | `provenance/uniprot_interpro.tsv` | `c71c9e67ee7a74ca36ed94f441f5b7197dc670e2c67b813aa3a7111d14ee2eeb` |
| Acquisition URLs and roles | `provenance/SOURCE_ACQUISITION_LEDGER.md` | `4b937462af8c3192e5410eb91997a6f37756628f83b081cc5b1a81ef58ccff19` |

## Reproduce
```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r environment/requirements.txt
python evidence/run_r0.py
```

The script reads local source copies under `provenance/` and overwrites `evidence/results.json` and `evidence/oof_predictions.csv`. Use the pinned environment for byte-level output comparison.

## Directory map
- `paper/`: accepted 5-page research paper in editable DOCX and PDF.
- `technical_report/`: 21-page technical report in editable DOCX and PDF.
- `evidence/`: protocol, digest, executable analysis, machine results, OOF predictions.
- `provenance/`: exact acquired sources and acquisition ledger.
- `environment/`: pinned dependencies and reproduction notes.
- `manifests/`: per-file manifest and standard SHA-256 list.

## Verification
From the package root:
```bash
sha256sum -c manifests/MANIFEST.sha256
```
The manifest intentionally excludes itself and `FILE_MANIFEST.tsv` to avoid recursive hashing.
