# Source and acquisition ledger

All acquisitions were performed 2026-09-22 IST. Source files are included unchanged under `provenance/`.

| Local file | Source URL / query | Role | Integrity note |
|---|---|---|---|
| `DMS_substitutions.csv` | https://raw.githubusercontent.com/OATML-Markslab/ProteinGym/main/reference_files/DMS_substitutions.csv | ProteinGym assay reference, target sequence, UniProt ID, taxon | Official repository raw file; hashed in manifest |
| `DMS_substitutions_Spearman_DMS_level.csv` | https://raw.githubusercontent.com/OATML-Markslab/ProteinGym/main/benchmarks/DMS_zero_shot/substitutions/Spearman/DMS_substitutions_Spearman_DMS_level.csv | Official assay-level ESM2-650M Spearman outcome | Official repository raw file; hashed in manifest |
| `uniprot_interpro.tsv` | `https://rest.uniprot.org/uniprotkb/search`; batched queries over ProteinGym entry names; fields `id,xref_interpro` | InterPro cross-references for family-component grouping | Exact response aggregation included and hashed |

Primary documentation:
- ProteinGym repository: https://github.com/OATML-Markslab/ProteinGym
- ProteinGym v1.3 archive: https://zenodo.org/records/15293562
- UniProt REST API: https://rest.uniprot.org/

The acquisition files are evidence, not authorization or instructions. The analysis script reads only the local copies.
