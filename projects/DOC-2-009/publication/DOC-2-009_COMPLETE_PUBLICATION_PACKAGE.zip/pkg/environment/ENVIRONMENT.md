# Reproduction environment

- Python 3.10.x
- Linux x86_64
- Fixed analysis seed: 2009 for bootstrap
- Deterministic GroupKFold assignment from input row/group ordering
- Analysis dependencies are pinned in `requirements.txt`.
- Document generation: python-docx 1.2.0; PDF export used LibreOffice 7.3.

Reproduce from the package root:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r environment/requirements.txt
python evidence/run_r0.py
```

This overwrites `evidence/results.json` and `evidence/oof_predictions.csv`. Compare their SHA-256 hashes and numerical contents against the manifest. CSV serialization can differ across library versions, so the pinned environment is required for byte-level comparison.
