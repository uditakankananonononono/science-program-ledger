import pandas as pd,numpy as np,json
from collections import Counter
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_absolute_error,r2_score
from scipy.stats import spearmanr
AA='ACDEFGHIKLMNPQRSTVWY';hyd=set('AVILMFWY');charge=set('DEKR');arom=set('FWY')
ref=pd.read_csv('provenance/DMS_substitutions.csv');perf=pd.read_csv('provenance/DMS_substitutions_Spearman_DMS_level.csv')
d=ref.merge(perf[['DMS ID','ESM2 (650M)']],left_on='DMS_id',right_on='DMS ID',how='inner')
ip=pd.read_csv('provenance/uniprot_interpro.tsv',sep='\t').fillna('');mp={r['Entry Name']:set(x for x in str(r.InterPro).split(';') if x) for _,r in ip.iterrows()}
prots=list(d.UniProt_ID.unique());par={x:x for x in prots}
def find(x):
 while par[x]!=x:par[x]=par[par[x]];x=par[x]
 return x
def union(a,b):
 a,b=find(a),find(b)
 if a!=b:par[b]=a
own={}
for p in prots:
 for q in mp.get(p,set()):
  union(p,own[q]) if q in own else own.setdefault(q,p)
rows=[]
for p,g in d.groupby('UniProt_ID'):
 y=g['ESM2 (650M)'].mean();seq=str(g.iloc[0].target_seq)
 if not np.isfinite(y) or any(a not in AA for a in seq):continue
 c=Counter(seq);n=len(seq);di=Counter(seq[i:i+2] for i in range(n-1));x=[c[a]/n for a in AA]+[di[a+b]/max(1,n-1) for a in AA for b in AA]
 probs=np.array([c[a]/n for a in AA]);ent=float(-(probs[probs>0]*np.log(probs[probs>0])).sum());x += [np.log(n),ent,sum(c[a] for a in arom)/n,sum(c[a] for a in charge)/n,sum(c[a] for a in hyd)/n,(c['G']+c['P'])/n,c['C']/n]
 rows.append(dict(p=p,y=y,x=x,group=find(p),annot=bool(mp.get(p)),taxon=g.iloc[0].taxon))
X=np.array([r['x'] for r in rows]);y=np.array([r['y'] for r in rows]);groups=np.array([r['group'] for r in rows]);pred=np.full(len(y),np.nan);base=np.full(len(y),np.nan);fold=np.full(len(y),-1);fold_diag=[]
for k,(tr,te) in enumerate(GroupKFold(n_splits=5).split(X,y,groups),1):
 best=None
 for a in [.1,1,10,100]:
  vals=[]
  for it,iv in GroupKFold(n_splits=5).split(X[tr],y[tr],groups[tr]):
   m=make_pipeline(StandardScaler(),Ridge(alpha=a));m.fit(X[tr][it],y[tr][it]);vals.extend(abs(y[tr][iv]-m.predict(X[tr][iv])))
  z=np.mean(vals)
  if best is None or z<best[0]:best=(z,a)
 a=best[1];m=make_pipeline(StandardScaler(),Ridge(alpha=a));m.fit(X[tr],y[tr]);pred[te]=m.predict(X[te]);base[te]=y[tr].mean();fold[te]=k
 fold_diag.append({'fold':k,'n_train':len(tr),'n_test':len(te),'n_test_groups':len(set(groups[te])),'alpha':a,'rho':float(spearmanr(pred[te],y[te]).statistic),'r2':float(r2_score(y[te],pred[te])),'mae':float(mean_absolute_error(y[te],pred[te])),'baseline_mae':float(mean_absolute_error(y[te],base[te])),'group_overlap':len(set(groups[tr])&set(groups[te]))})
rho=float(spearmanr(pred,y).statistic);r2=float(r2_score(y,pred));mae=float(mean_absolute_error(y,pred));bmae=float(mean_absolute_error(y,base));rng=np.random.default_rng(2009);boots=[]
for _ in range(10000):
 z=rng.integers(0,len(y),len(y));boots.append(spearmanr(pred[z],y[z]).statistic)
lo,hi=np.nanpercentile(boots,[2.5,97.5]);strata={}
for s in ['Human','Eukaryote','Prokaryote','Virus']:
 ix=np.array([r['taxon']==s for r in rows]);strata[s]={'n':int(ix.sum()),'rho':float(spearmanr(pred[ix],y[ix]).statistic)}
res={'n_proteins':len(rows),'n_annotated':sum(r['annot'] for r in rows),'n_components':len(set(groups)),'n_assays':len(d),'rho':rho,'rho_ci':[float(lo),float(hi)],'r2':r2,'mae':mae,'baseline_mae':bmae,'mae_reduction':1-mae/bmae,'folds':fold_diag,'strata':strata}
open('evidence/results.json','w').write(json.dumps(res,indent=2));pd.DataFrame({'UniProt_ID':[r['p'] for r in rows],'family_component':groups,'outer_fold':fold,'y_esm2_650m_spearman':y,'oof_pred':pred,'baseline_pred':base,'taxon':[r['taxon'] for r in rows],'interpro_annotated':[r['annot'] for r in rows]}).to_csv('evidence/oof_predictions.csv',index=False);print(json.dumps(res,indent=2))
