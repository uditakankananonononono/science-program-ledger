# DOC-2-019 R2 prospective lock
## Weakest-link forward-model discordance on external RNA generators

**Status:** Proposed for independent adjudication; unexecuted.  
**Lock date:** 22 September 2026 IST.  
**Outcome firewall:** No OpenKnot score, SHAPE/reactivity value, RNet F1 value, RNet structure, detector score, or outcome distribution has been inspected. Only field presence and non-outcome metadata counts were audited. `outcome_fields_accessed=false`.

## 1. Independent successor mechanism

R1.1 asked whether a fitted 120-feature sequence/topology classifier could learn experimental score failure among gRNAde submissions. R2 does not tune that classifier. It changes both the named generator and the mechanism.

- **External generators:** Struct2SeQ and Struct2SeQ-SHAPE, two exact method labels from an independent deep-Q-learning RNA inverse-folding system.
- **Independent mechanism:** forward-model **weakest-link discordance**. A design is high risk when an independent sequence-to-structure predictor gives poor agreement with the intended target overall or specifically on crossed pseudoknot pairs. The mechanism is not learned from OpenKnot outcomes.
- **Frozen risk score:**  
  `risk = 100 - min(RNet_F1, RNet_F1_crossed_pair)`  
  where both benchmark fields are on the documented 0-100 F1 scale. Higher risk predicts an OpenKnot score below 80.

The minimum implements a prespecified bottleneck hypothesis: a design is only as strong as its weaker global or crossed-pair structural agreement. It is not selected from R1.1 results or any R2 outcome.

## 2. Sources and availability audit

### 2.1 Struct2SeQ

- Code: https://github.com/Shujun-He/Struct2SeQ
- Commit: `381b7f6aa33e0ba64b436294de4cccbc721ffdcd`
- License: MIT; pinned LICENSE SHA-256 `c2f5feddc97602e114f5c250876b434275c38dd267f5fa550283e21fe31f8cbd`
- Code README SHA-256: `666891b3867705cd20c44913b752e1e57f685d1e28926d0ce48e78a74351d684`
- Public model weights: Kaggle `shujun717/struct2seq-weights`, 239,473,802 bytes, CC0, last updated 12 January 2026.
- Public forward-model weights: Kaggle `shujun717/ribonanzanet-weights`, 181,652,848 bytes, MIT.

The repository documents deep-Q-learning generation conditioned on target secondary structure and optional SHAPE constraints. Its two benchmark labels are `Struct2SeQ` and `Struct2SeQ-SHAPE`.

### 2.2 Experimental benchmark

- Eterna OpenKnot data commit: `211a90e2b0dcc47d1a0325a6737e3b48bf76da52`
- File: `Data/OpenKnotBench_data.v4.5.1.csv`
- SHA-256: `22fa72df6d98f86fbf37a57e679f717628a5d5db3737df3f5519901bc9777901`
- License: Apache-2.0.
- Assay: 2A3-MaP SHAPE chemical mapping.

Metadata-only audit found exactly 400 rows per method per round in rounds 3 and 4, across 20 puzzles each. Assay-quality counts were 387/400 and 385/400 for Struct2SeQ in rounds 3/4, and 391/400 and 386/400 for Struct2SeQ-SHAPE. All 1,600 candidate rows had valid sequence-target lengths. RNet structure, overall F1, and crossed-pair F1 fields were present on all candidate rows. Values were not read.

## 3. Endpoint orientation and claim boundary

The endpoint is **OpenKnot score below the external 80 benchmark**. Failure = `target_openknot_score < 80`; success = score >=80. Orientation remains fixed by official commit-pinned text:

- OpenKnot score runs from 0 to 100, with higher values more likely to represent pseudoknots.
- A score above 80 is estimated to have a good chance of representing a pseudoknot.
- RNA below 80 may still form pseudoknots because SHAPE cannot distinguish them.

Allowed claim: weakest-link forward-model discordance did or did not discriminate below-80 experimental scores among submitted, assayed Struct2SeQ designs in a later round. Forbidden claims include molecular non-formation, universal hallucination detection, causality, or performance on unscreened outputs.

## 4. Cohort and prediction unit

Include only rows satisfying all conditions:

1. exact method in `{Struct2SeQ, Struct2SeQ-SHAPE}`;
2. exact experiment type `2A3_MaP`;
3. `SN_filter=1`;
4. round 3 or 4;
5. nonmissing puzzle and ID;
6. normalized design sequence contains only A/C/G/U after whitespace removal, uppercasing and T-to-U;
7. normalized target uses only `.()[]{}<>`, has equal length, and passes the strict R1.1 bracket parser;
8. after the applicable outcome layer is opened, finite `RNet_F1`, `RNet_F1_crossed_pair`, and OpenKnot score, each in [0,100].

Before any values are loaded, define unit key `(method, puzzle, normalized sequence, normalized target)`. Retain every assay replicate. For duplicate rows, the unit endpoint is the prespecified median OpenKnot score and each RNet component is its prespecified median. Even-count median is the mean of the two central sorted values. Representative ID is lexicographically smallest UTF-8 ID, then original zero-based CSV row number.

Same sequence with different target or method remains a distinct unit. A round-4 sequence matching any round-3 sequence within the same method is excluded. A round-4 sequence appearing under multiple puzzles within the same method is excluded. Exclusions are fixed before values.

## 5. Temporal split and access order

- **Development:** round 3 only.
- **No-touch test:** round 4 only.

Execution order:

1. Verify hashes; run parser/schema tests; form unit keys and exclusions; write metadata flow and puzzle map; seal all hashes.
2. Apply metadata gates without reading RNet or endpoint values.
3. Load round-3 RNet and endpoint values only; verify class support; compute development diagnostics, descriptive review tiers, and controls; seal.
4. Load round-4 RNet and endpoint values once; compute all test results unchanged.

No R2 value may modify the risk function, cohort, endpoint, baseline, subgroup, gates, or tool behavior.

## 6. Frozen scores and baselines

### 6.1 Primary score

`risk_weakest = 100 - min(RNet_F1, RNet_F1_crossed_pair)`

The score is deterministic and unfitted.

### 6.2 Mechanism ablation

`risk_global = 100 - RNet_F1`

This tests whether adding the crossed-pair bottleneck improves over global predicted structure agreement alone.

### 6.3 Handcrafted baselines

- `risk_length_gc`: round-3-fitted L2 logistic regression using only log length and GC fraction; exact solver and C grid copied from the approved R1.1 implementation. Group folds are puzzles sorted by UTF-8 order with fold `i mod 5`; candidate C `{0.01,0.1,1,10,100}`, ties smaller C.
- `risk_canonical = 1 - canonical_target_pair_fraction`, unfitted.

Handcrafted features use the approved R1.1 parser definitions. They do not reuse the 120-feature fitted detector.

## 7. Primary estimand and uncertainty

For each `(method, puzzle)` group with both endpoint classes, compute AUROC for `risk_weakest`. The **primary estimand** is the unweighted mean over all evaluable method-puzzle groups in round 4. Thus each generator variant and puzzle receives equal weight.

Cluster bootstrap: sample the 20 round-4 puzzles with replacement 10,000 times using NumPy seed `2019`; each sampled puzzle carries both method groups. Recompute the primary macro AUROC. Use percentile 95% interval.

Paired differences use identical sampled puzzle indices:

- primary minus `risk_global`;
- primary minus `risk_length_gc`;
- primary minus `risk_canonical`.

Report method-specific puzzle-macro AUROCs and bootstrap intervals by sampling puzzles within each method. Report pooled AUROC and average precision only as descriptive.

## 8. Locked success gates - all required

R2 is positive only if all gates pass:

1. **Primary discrimination:** combined method-puzzle macro AUROC >=0.70.
2. **Precision:** puzzle-bootstrap 95% lower bound >=0.60.
3. **Mechanism increment:** primary minus global-F1 ablation >=0.02, and paired 95% CI lower bound >0.00.
4. **Added value over handcrafted baselines:** primary exceeds the better of length+GC and canonical-pair baselines by >=0.05. Paired CIs are reported but do not gate this item.
5. **External-model replication:** method-specific macro AUROC >=0.65 for both Struct2SeQ and Struct2SeQ-SHAPE.
6. **Directional consistency:** at least 70% of evaluable method-puzzle groups have AUROC >0.50.

No secondary analysis rescues a failed gate. This six-gate rule is deliberately stronger than a single favorable aggregate.

## 9. Feasibility and fail-closed rules

Before value access, require:

- >=300 eligible units per method in round 3 and >=300 per method in round 4;
- all 20 puzzles represented per method per round;
- parser yield >=95%;
- RNet field presence >=95%.

After round-3 values load, require each method has >=10 puzzles with both endpoint classes. If not, endpoint-infeasible and round-4 outcomes remain unopened.

After round-4 values load, require >=10 mixed-class method-puzzle groups total and >=5 per method. Otherwise endpoint-infeasible; pooled metrics cannot replace the primary estimand.

Missing or out-of-range RNet values make a unit ineligible; counts and reasons are reported. No imputation. A tie-only method-puzzle AUROC of 0.5 is valid; a single-class group is not evaluable.

## 10. Controls

Before values:

- source/lock/schema hashes;
- strict parser unit tests;
- unit-key determinism and row-permutation invariance;
- exact method/round/puzzle map and hash;
- forbidden-field access test in metadata code.

After development values, before test:

- risk orientation test on synthetic fixtures: lowering either RNet component cannot lower risk;
- bounds test: both components 100 gives risk 0; either component 0 gives risk 100;
- within-method/puzzle label shuffle, 100 seeds `2020000+j`; mean primary AUROC must be 0.40-0.60;
- inversion identity within every mixed development group to `1e-12`;
- length+GC convergence warnings are fatal.

After test, no control may trigger parameter repair. A code failure may be fixed only under the same-spec repair rule with a written pre-rerun note.

## 11. Prespecified descriptive analyses

These never alter the gate verdict:

- round-4 performance by method;
- performance by development-median target length, tie rule `<=` short and `>` long;
- performance by development-median crossed-pair fraction;
- AUROC using overall F1 alone and crossed F1 alone;
- Spearman correlations between each RNet component, risk, and OpenKnot score within method;
- failure prevalence by method and puzzle;
- top-decile review enrichment using a **development risk quantile**, not a test-derived threshold.

## 12. Review-support tool surface

R2 includes a separate, outcome-blind review surface because topic graduation requires a tested decision-support artifact. It does not affect scientific gates.

### 12.1 Tool behavior

Input: CSV with `design_id`, `method`, `puzzle`, `sequence`, `target_structure`, `RNet_F1`, and `RNet_F1_crossed_pair`.

Output for each design:

- weakest-link risk on 0-100 scale;
- global and crossed-pair components;
- which component is the bottleneck;
- review tier based on **round-3 risk quantiles only**: high = at or above development 80th percentile; medium = 50th to <80th; low = below 50th;
- validation warnings for malformed sequence/target or out-of-range values;
- explicit text: "Review priority, not proof of molecular failure."

The surface may sort/filter and export a review queue. It must never display a probability of molecular failure.

### 12.2 Locked tool tests

Before round-4 outcomes:

- unit tests for score monotonicity, boundaries, ties, malformed rows, exact quantile tie rules, stable sorting `(tier rank, risk descending, design_id UTF-8 ascending)`, and CSV round-trip;
- schema test on at least 20 synthetic fixtures;
- visual verification at 390px and 1280px widths with no clipping, unreadable labels, or hidden caveat;
- accessibility: keyboard-reachable controls, text labels, and color-independent tier names;
- provenance panel shows lock SHA, source hash, development quantile hashes, and generation timestamp.

After R2 outcomes, populate the tool with test predictions only after scientific result files are sealed. Tool usability does not rescue scientific failure.

## 13. Software, compute, and output discipline

Environment frozen before execution: Python 3.10.12; NumPy 2.2.6; SciPy 1.15.3; pandas 2.3.3; scikit-learn 1.6.1. Exact wheels and hashes recorded.

Compute ceiling: 8 CPU cores, 32 GiB RSS, six wall-clock hours, and 20 GiB local disk. Record stage times, CPU, RSS, input/output bytes, and exit codes.

All JSON uses `allow_nan=false`. Every output includes protocol ID, lock SHA, source SHA, Struct2SeQ commit, run ID, and value-access phase. Preserve complete raw replicate rows, unit predictions, group metrics, 10,000 bootstrap draws, paired differences, gates, exclusions, controls, and tool-test evidence.

At completion create a deterministic archive, upload to two independent durable destinations, download/read back both, and verify archive plus every internal manifest hash. Until both verify, status is `complete-but-not-durably-sealed`.

## 14. Adjudication request

Approve, reject, or amend this lock before any RNet F1 or OpenKnot outcome value is read. Any change after approval requires a versioned lock and new SHA before value access.
