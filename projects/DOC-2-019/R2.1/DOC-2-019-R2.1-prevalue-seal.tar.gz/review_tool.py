#!/usr/bin/env python3
"""DOC-2-019 R2.1 synthetic-fixture benchmark review queue. No endpoint access."""
import csv,hashlib,json,math,sys
TIERS={'high':0,'medium':1,'low':2}
def score(row,q50,q80):
 vals=[]
 for k in ('RNet_F1','RNet_F1_crossed_pair'):
  try:v=float(row[k]);assert math.isfinite(v) and 0<=v<=100
  except:raise ValueError(f'invalid_{k}')
  vals.append(v)
 risk=100-min(vals);tier='high' if risk>=q80 else ('medium' if risk>=q50 else 'low');b='global' if vals[0]<vals[1] else ('crossed' if vals[1]<vals[0] else 'tie')
 return dict(design_id=row['design_id'],method=row['method'],puzzle=row['puzzle'],risk=risk,global_f1=vals[0],crossed_f1=vals[1],bottleneck=b,tier=tier,caveat='Review priority, not proof of molecular failure.')
def run(inp,out,q50=30,q80=60):
 rows=[]
 with open(inp,newline='') as f:
  r=csv.DictReader(f);need={'design_id','method','puzzle','sequence','target_structure','RNet_F1','RNet_F1_crossed_pair'}
  if not need<=set(r.fieldnames or []):raise ValueError('schema')
  for x in r:rows.append(score(x,q50,q80))
 rows.sort(key=lambda z:(TIERS[z['tier']],-z['risk'],z['design_id'].encode()))
 with open(out,'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 return rows
if __name__=='__main__':run(sys.argv[1],sys.argv[2])
