import csv,json,hashlib
from collections import Counter,defaultdict
p='OpenKnotBench_data.v4.5.1.csv'; methods={'Struct2SeQ','Struct2SeQ-SHAPE'}
counts=Counter();puzzles=defaultdict(set);seqs=defaultdict(set);sn=Counter();valid=Counter();total=0
allowed=['id','round','puzzle','method','experiment_type','SN_filter','design_sequence','target_structure']
with open(p,newline='') as f:
 r=csv.DictReader(f)
 for raw in r:
  row={k:raw.get(k,'') for k in allowed}
  if row['method'] not in methods:continue
  total+=1;k=(row['method'],row['round']);counts[k]+=1;puzzles[k].add(row['puzzle']);sn[(k,row['SN_filter'])]+=1
  s=''.join(row['design_sequence'].split()).upper().replace('T','U');t=''.join(row['target_structure'].split())
  if s and len(s)==len(t) and set(s)<=set('ACGU'):valid[k]+=1;seqs[k].add(hashlib.sha256(s.encode()).hexdigest())
out={'source_sha256':hashlib.sha256(open(p,'rb').read()).hexdigest(),'outcome_fields_accessed':False,'total_candidate_rows':total,'by_method_round':[]}
for k in sorted(counts):out['by_method_round'].append({'method':k[0],'round':k[1],'rows':counts[k],'puzzles':len(puzzles[k]),'SN_filter_1':sn[(k,'1')],'SN_filter_0':sn[(k,'0')],'valid_sequence_target_rows':valid[k],'unique_sequence_hashes':len(seqs[k])})
json.dump(out,open('metadata_audit_r2.json','w'),indent=2,sort_keys=True,allow_nan=False);print(json.dumps(out,indent=2))
