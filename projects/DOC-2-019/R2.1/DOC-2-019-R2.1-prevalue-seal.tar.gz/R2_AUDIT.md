# DOC-2-019 R2 availability audit

**Verdict:** Feasible without outcome access.

The successor changes the named generator from gRNAde to Struct2SeQ and Struct2SeQ-SHAPE and replaces R1.1's fitted sequence/topology classifier with an unfitted weakest-link forward-model discordance mechanism.

Public code, licenses, and model-weight records are available. The commit-pinned OpenKnot table has 400 rows per method in both rounds 3 and 4 across all 20 puzzles. Assay-quality pass counts remain above 385 per method-round. Valid sequence/target fields and both RNet F1 field presences are complete. The audit read field presence only, not computational scores or experimental outcomes.

The same experimental benchmark is retained to enable a temporal test and direct comparison, but the external generator family and mechanism are independent. The narrow claim and selection caveat remain explicit.
