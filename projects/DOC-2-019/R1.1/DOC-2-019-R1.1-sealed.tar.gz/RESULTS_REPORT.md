# DOC-2-019 R1.1 results

## Verdict
**Negative under all five locked gates.** The frozen sequence/target-topology detector did not discriminate later-round OpenKnot score below the external 80 benchmark among submitted, assayed gRNAde designs. This endpoint is an experimental score failure, not proof of molecular non-formation: official OpenKnot documentation says RNA below 80 may still form pseudoknots because SHAPE cannot distinguish them.

## Locked test result
- 357 test prediction units; 15 round-4 puzzles had both endpoint classes.
- Primary puzzle-macro AUROC: **0.5238**.
- Puzzle-bootstrap 95% CI: **0.3853-0.6657**.
- Length+GC baseline AUROC: **0.6236**; primary difference **-0.0997** (paired 95% CI -0.2188 to 0.0120).
- Canonical-pair baseline AUROC: **0.5547**; primary difference **-0.0308** (paired 95% CI -0.2324 to 0.1575).
- Long stratum AUROC: 0.5238. The short stratum had no mixed-class puzzles and was unevaluable, so the locked two-stratum gate failed closed.
- 40% of evaluable puzzles had AUROC >0.50.

## Gate table
| Locked gate | Observed | Pass |
|---|---:|:---:|
| Puzzle-macro AUROC >=0.75 | 0.5238 | No |
| Bootstrap lower bound >=0.65 | 0.3853 | No |
| Improvement >=0.05 over better baseline | -0.0997 | No |
| AUROC >=0.70 in both development-cut length strata | long 0.5238; short unevaluable | No |
| >=70% puzzles AUROC >0.50 | 40% | No |

## Development and controls
Metadata gates passed before labels: 970 development units, 357 unexcluded test units, 31 development puzzles, 20 test puzzles, parser yield 100%. Frozen five-fold development selected C=100; development CV puzzle-macro AUROC was 0.6534. Length+GC baseline selected C=0.1 and reached 0.6744. The 100 within-puzzle label-shuffle runs averaged 0.4965. Parser, schema, inversion, hash, fold-class and convergence controls passed.

## Execution notes
The first test attempt hit a fail-closed gate-rendering bug because an unevaluable stratum returned null. The locked rule was implemented unchanged: an undefined stratum cannot pass. Two later failures were strict JSON and console serialization of NumPy booleans. All three fixes were documented as same-spec repairs; no threshold, feature, cohort, model, endpoint or result changed. The final serialized prediction and bootstrap files were reproduced with stable hashes.
