#!/usr/bin/env python3
import argparse,csv,hashlib,json,math,os,platform,resource,sys,time,warnings
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
from scipy.stats import rankdata

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'OpenKnotBench_data.v4.5.1.csv'; LOCK=ROOT/'PROSPECTIVE_R1_LOCK_v1.1_AMENDED.md'; SCHEMA=ROOT/'feature_schema_v1.json'
PROTOCOL='DOC-2-019-R1.1'; LOCK_SHA='ccd70bb8c47b34b33f1bbcfc00798e48cfdaa918131f6c84eb159624a0fe97b6'; DATA_SHA='22fa72df6d98f86fbf37a57e679f717628a5d5db3737df3f5519901bc9777901'; SCHEMA_SHA='04bee8d4bbc448a0c45138c1820955836adb131fe8af6323e915d23f999e63d5'
PAIRS={'(':')','[':']','{':'}','<':'>'}; CLOSE={v:k for k,v in PAIRS.items()}; BASE='ACGU'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(obj,p):
 with open(p,'w') as f: json.dump(obj,f,indent=2,allow_nan=False,sort_keys=True,default=lambda z: z.item() if isinstance(z,np.generic) else (_ for _ in ()).throw(TypeError(type(z).__name__)))
def normseq(s): return ''.join(s.split()).upper().replace('T','U')
def normtarget(s): return ''.join(s.split())
def parse_target(s):
 if any(c not in '.()[]{}<>' for c in s): raise ValueError('illegal_target_character')
 stacks={x:[] for x in PAIRS}; pairs=[]
 for i,c in enumerate(s):
  if c in PAIRS: stacks[c].append(i)
  elif c in CLOSE:
   op=CLOSE[c]
   if not stacks[op]: raise ValueError('unbalanced_close')
   pairs.append((stacks[op].pop(),i,c))
 if any(stacks[x] for x in stacks): raise ValueError('unbalanced_open')
 return sorted(pairs)
def ent(chars):
 if not chars:return 0.
 c=Counter(chars); return -sum((v/len(chars))*math.log(v/len(chars)) for v in c.values())/math.log(4)
def features(seq,tgt):
 if len(seq)!=len(tgt): raise ValueError('unequal_length')
 L=len(seq); pairs=parse_target(tgt); pairedpos={i for a,b,_ in pairs for i in (a,b)}; unpaired=[i for i in range(L) if i not in pairedpos]
 out=[]; out += [float(L),(seq.count('G')+seq.count('C'))/L]+[seq.count(b)/L for b in BASE]+[ent(seq)]
 runs=[]; st=0
 for i in range(1,L+1):
  if i==L or seq[i]!=seq[st]: runs.append(i-st); st=i
 out += [max(runs)/L,sum(x for x in runs if x>=4)/L]
 for k in (2,3):
  den=L-k+1
  for tup in __import__('itertools').product(BASE,repeat=k): out.append(sum(seq[i:i+k]==''.join(tup) for i in range(den))/den)
 out += [sum(seq[i:i+2]=='CG' for i in range(L-1))/(L-1),sum(seq[i:i+2]=='UA' for i in range(L-1))/(L-1)]
 npair=len(pairs); crossset=set()
 for u,(a,b,_) in enumerate(pairs):
  for v,(c,d,_) in enumerate(pairs[u+1:],u+1):
   if (a<c<b<d) or (c<a<d<b):crossset|={u,v}
 stems=[]; used=set(); pairloc={(a,b):i for i,(a,b,_) in enumerate(pairs)}
 for i,(a,b,_) in enumerate(pairs):
  if i in used:continue
  stem=[];x,y=a,b
  while (x,y) in pairloc: q=pairloc[(x,y)];stem.append(q);used.add(q);x+=1;y-=1
  stems.append(stem)
 uruns=[]; st=None
 for i in range(L+1):
  if i<L and i in unpaired and st is None:st=i
  if st is not None and (i==L or i not in unpaired):uruns.append(i-st);st=None
 pk=sum(br!=')' for _,_,br in pairs)
 out += [len(pairedpos)/L,npair/L,pk/npair if npair else 0.,len(crossset)/npair if npair else 0.,max((b-a for a,b,_ in pairs),default=0)/L,len(stems)/L,(np.mean([len(x) for x in stems])/L if stems else 0.),(max([len(x) for x in stems],default=0)/L),(np.mean(uruns)/L if uruns else 0.),(max(uruns,default=0)/L)]
 pc=Counter(seq[a]+seq[b] for a,b,_ in pairs); den=npair or 1
 vals=[pc[x]/den for x in ['AU','UA','GC','CG','GU','UG']]; non=1-sum(vals) if npair else 0
 canon=sum(vals); gc=(pc['GC']+pc['CG'])/den if npair else 0; wob=(pc['GU']+pc['UG'])/den if npair else 0
 cp=[pairs[i] for i in sorted(crossset)]; cc=sum((seq[a]+seq[b]) in {'AU','UA','GC','CG','GU','UG'} for a,b,_ in cp)/(len(cp) or 1)
 cnon=(1-cc) if cp else 0
 pgc=np.mean([seq[i] in 'GC' for i in pairedpos]) if pairedpos else 0; ugc=np.mean([seq[i] in 'GC' for i in unpaired]) if unpaired else 0
 out += vals+[non,canon,gc,wob,cc,cnon,abs(pgc-ugc),ent(''.join(seq[i] for i in sorted(pairedpos))),ent(''.join(seq[i] for i in unpaired)),float(not npair),float(not cp),float(not unpaired),float(not pairedpos)]
 return np.asarray(out,float)
def auc(y,s):
 y=np.asarray(y);s=np.asarray(s); n1=(y==1).sum();n0=(y==0).sum()
 if not n1 or not n0:return None
 return float((rankdata(s)[y==1].sum()-n1*(n1+1)/2)/(n1*n0))
def ap(y,s):
 y=np.asarray(y);s=np.asarray(s); n=y.sum()
 if n==0:return None
 order=np.argsort(-s,kind='mergesort'); yy=y[order]; return float(np.sum(np.cumsum(yy)/(np.arange(len(y))+1)*yy)/n)
def macro(rows,scores,metric=auc):
 by=defaultdict(lambda:[[],[]])
 for r,q in zip(rows,scores):by[r['puzzle']][0].append(r['y']);by[r['puzzle']][1].append(q)
 d={k:metric(*v) for k,v in by.items()};d={k:v for k,v in d.items() if v is not None}; return (float(np.mean(list(d.values()))) if d else None),d
def unit_key(p,s,t): return hashlib.sha256((p+'\0'+s+'\0'+t).encode()).hexdigest()
def controls():
 cases=[('((..))',True),('([)]',True),(')',False),('(',False),('(a)',False),('...',True)]
 for s,ok in cases:
  try:parse_target(s); got=True
  except ValueError:got=False
  assert got==ok,(s,got)
 try: features('ACG','..'); got=True
 except ValueError: got=False
 assert not got

def phase_meta():
 assert sha(DATA)==DATA_SHA and sha(LOCK)==LOCK_SHA and sha(SCHEMA)==SCHEMA_SHA; controls()
 schema=json.load(open(SCHEMA))['order']; req=['id','sequence','experiment_type','SN_filter','round','puzzle','method','design_sequence','target_structure']
 records=[]; rejects=Counter(); totalq=0
 with open(DATA,newline='') as f:
  rr=csv.reader(f); hdr=next(rr); ix={x:hdr.index(x) for x in req}
  assert all(x in hdr for x in req)
  for rownum,row in enumerate(rr,1):
   vals={x:row[ix[x]] for x in req}
   if vals['method']!='gRNAde' or vals['experiment_type']!='2A3_MaP' or vals['SN_filter']!='1' or vals['round'] not in {'1','2','3','4'}:continue
   totalq+=1
   try:
    assert vals['id'] and vals['puzzle']; s=normseq(vals['design_sequence']);t=normtarget(vals['target_structure']); assert len(s)>=3 and len(s)==len(t) and set(s)<=set(BASE)
    x=features(s,t); assert len(x)==120 and np.isfinite(x).all()
   except Exception as e: rejects[type(e).__name__+':'+str(e)]+=1;continue
   records.append({'rownum':rownum,'id':vals['id'],'round':int(vals['round']),'puzzle':vals['puzzle'],'seq':s,'target':t,'key':unit_key(vals['puzzle'],s,t),'x':x.tolist()})
 assert np.array_equal(features(records[0]['seq'],records[0]['target']),features(records[0]['seq'],records[0]['target']))
 # unit metadata partition; test leak/cross-puzzle exclusions fixed now
 units=defaultdict(list)
 for r in records:units[r['key']].append(r)
 devseq={r['seq'] for r in records if r['round']<=3}; test_seq_puzzles=defaultdict(set)
 for r in records:
  if r['round']==4:test_seq_puzzles[r['seq']].add(r['puzzle'])
 unitrows=[]; rawmeta=[]
 for key,rs in sorted(units.items()):
  for r in rs:rawmeta.append({k:r[k] for k in ['rownum','id','round','puzzle','key']})
  for part,sel in [('dev',[r for r in rs if r['round']<=3]),('test',[r for r in rs if r['round']==4])]:
   if not sel:continue
   excluded=''
   if part=='test' and sel[0]['seq'] in devseq:excluded='sequence_matches_development'
   if part=='test' and len(test_seq_puzzles[sel[0]['seq']])>1:excluded='sequence_in_multiple_test_puzzles'
   chosen=sorted(sel,key=lambda r:(r['id'].encode(),r['rownum']))[0]
   unitrows.append({'key':key,'part':part,'puzzle':chosen['puzzle'],'seq':chosen['seq'],'target':chosen['target'],'length':len(chosen['seq']),'x':chosen['x'],'replicate_rownums':[r['rownum'] for r in sorted(sel,key=lambda r:r['rownum'])],'representative_id':chosen['id'],'excluded':excluded})
 devp=sorted({u['puzzle'] for u in unitrows if u['part']=='dev'},key=lambda s:s.encode()); folds={p:i%5 for i,p in enumerate(devp)}
 with open('fold_map.csv','w',newline='') as f:
  w=csv.writer(f);w.writerow(['puzzle','fold']);w.writerows((p,folds[p]) for p in devp)
 dump(unitrows,'keyed_features.json');dump(rawmeta,'raw_metadata.json')
 gates={'dev_units':sum(u['part']=='dev' for u in unitrows),'test_units_unexcluded':sum(u['part']=='test' and not u['excluded'] for u in unitrows),'dev_puzzles':len(devp),'test_puzzles_unexcluded':len({u['puzzle'] for u in unitrows if u['part']=='test' and not u['excluded']}),'parser_yield':len(records)/totalq}
 gates['pass']=gates['dev_units']>=300 and gates['test_units_unexcluded']>=100 and gates['dev_puzzles']>=10 and gates['test_puzzles_unexcluded']>=10 and gates['parser_yield']>=.9
 manifest={'protocol_id':PROTOCOL,'outcome_fields_accessed':False,'lock_sha256':LOCK_SHA,'data_sha256':DATA_SHA,'schema_sha256':SCHEMA_SHA,'feature_order_sha256':sha(SCHEMA),'fold_map_sha256':sha('fold_map.csv'),'keyed_features_sha256':sha('keyed_features.json'),'feature_count':120,'metadata_gates':gates,'rejects':rejects}
 dump(manifest,'prelabel_manifest.json');print(json.dumps(manifest,indent=2,default=dict))
def median(v):
 a=sorted(v);n=len(a);return float(a[n//2] if n%2 else (a[n//2-1]+a[n//2])/2)
def load_labels(parts):
 wanted={n for u in json.load(open('keyed_features.json')) if u['part'] in parts for n in u['replicate_rownums']}
 out={}
 with open(DATA,newline='') as f:
  rr=csv.reader(f);hdr=next(rr);j=hdr.index('target_openknot_score')
  for n,row in enumerate(rr,1):
   if n in wanted:
    try:q=float(row[j]); assert math.isfinite(q) and 0<=q<=100;out[n]=q
    except:pass
 return out
def scale(A,mu=None,sd=None):
 A=np.asarray(A,float)
 if mu is None:mu=A.mean(0);sd=A.std(0);sd[sd==0]=1
 return (A-mu)/sd,mu,sd
def weights(y):
 y=np.asarray(y);n=len(y);c=Counter(y);return np.array([n/(2*c[z]) for z in y])
def fitpred(X,y,Xp,C):
 from sklearn.linear_model import LogisticRegression
 Z,mu,sd=scale(X);zp,_,_=scale(Xp,mu,sd)
 with warnings.catch_warnings(record=True) as w:
  warnings.simplefilter('always');m=LogisticRegression(penalty='l2',C=C,solver='liblinear',max_iter=5000,tol=1e-8,fit_intercept=True,intercept_scaling=1,class_weight=None,random_state=2019).fit(Z,y,sample_weight=weights(y))
  if w: raise RuntimeError(str(w))
 return m.predict_proba(zp)[:,1]
def cv_scores(rows,cols,C,labels):
 vals=[];pred=np.zeros(len(rows))
 for fold in range(5):
  tr=[i for i,r in enumerate(rows) if r['fold']!=fold];va=[i for i,r in enumerate(rows) if r['fold']==fold]
  p=fitpred(np.array([rows[i]['x'] for i in tr])[:,cols],[rows[i]['y'] for i in tr],np.array([rows[i]['x'] for i in va])[:,cols],C);pred[va]=p; vals.append(macro([rows[i] for i in va],p)[0])
 return float(np.mean(vals)),pred,vals
def phase_dev():
 assert json.load(open('prelabel_manifest.json'))['metadata_gates']['pass']; units=json.load(open('keyed_features.json')); fmap={r['puzzle']:int(r['fold']) for r in csv.DictReader(open('fold_map.csv'))}; lab=load_labels({'dev'})
 rows=[]
 for u in units:
  if u['part']!='dev':continue
  q=[lab[n] for n in u['replicate_rownums'] if n in lab]
  if not q:continue
  z=dict(u);z['endpoint']=median(q);z['y']=int(z['endpoint']<80);z['fold']=fmap[z['puzzle']];rows.append(z)
 for f in range(5):
  assert len({r['y'] for r in rows if r['fold']==f})==2 and len({r['y'] for r in rows if r['fold']!=f})==2
 grid=[];Cs=[.01,.1,1,10,100];cols=list(range(120));bcols=[0,1]
 for C in Cs:
  m,_,fs=cv_scores(rows,cols,C,lab);bm,_,bfs=cv_scores(rows,bcols,C,lab);grid.append({'C':C,'primary':m,'primary_folds':fs,'baselineA':bm,'baselineA_folds':bfs})
 cp=max(grid,key=lambda z:(z['primary'],-z['C']))['C'];cb=max(grid,key=lambda z:(z['baselineA'],-z['C']))['C']
 _,oof,_=cv_scores(rows,cols,cp,lab);_,boof,_=cv_scores(rows,bcols,cb,lab)
 # threshold balanced accuracy, ties largest
 cand=sorted(set(oof),reverse=True);best=max(cand,key=lambda t:((sum((oof>=t)&(np.array([r['y'] for r in rows])==1))/sum(r['y'] for r in rows)+sum((oof<t)&(np.array([r['y'] for r in rows])==0))/sum(1-r['y'] for r in rows))/2,t))
 # shuffle fixed C
 sh=[];yr=np.array([r['y'] for r in rows]);by=defaultdict(list)
 for i,r in enumerate(rows):by[r['puzzle']].append(i)
 for j in range(100):
  rng=np.random.default_rng(2019000+j);ys=yr.copy()
  for ix in by.values():ys[ix]=rng.permutation(ys[ix])
  sr=[dict(r,y=int(ys[i])) for i,r in enumerate(rows)];m,_,_=cv_scores(sr,cols,cp,lab);sh.append(m)
 assert .4<=np.mean(sh)<=.6
 # inversion each fold
 for f in range(5):
  ix=[i for i,r in enumerate(rows) if r['fold']==f];_,d=macro([rows[i] for i in ix],oof[ix]);_,di=macro([rows[i] for i in ix],-oof[ix]);assert all(abs(di[k]-(1-d[k]))<=1e-12 for k in d)
 dev_lengths=sorted(r['length'] for r in rows);lcut=median(dev_lengths);pkidx=json.load(open(SCHEMA))['order'].index('pk_bracket_pair_fraction');pcut=median([r['x'][pkidx] for r in rows])
 out={'protocol_id':PROTOCOL,'lock_sha256':LOCK_SHA,'source_sha256':DATA_SHA,'n':len(rows),'class_counts':Counter(r['y'] for r in rows),'chosen_C':cp,'baselineA_C':cb,'decision_threshold':best,'length_cut':lcut,'pk_cut':pcut,'cv_grid':grid,'shuffle_mean':float(np.mean(sh)),'shuffle_values':sh,'fold_map_sha256':sha('fold_map.csv'),'keyed_features_sha256':sha('keyed_features.json')}
 dump(out,'development_seal.json');dump([{k:r[k] for k in ['key','puzzle','fold','endpoint','y']}|{'oof':float(oof[i]),'baselineA_oof':float(boof[i])} for i,r in enumerate(rows)],'development_oof.json')
 print(json.dumps(out,indent=2,default=lambda x:dict(x)))
def phase_test():
 dev=json.load(open('development_seal.json'));units=json.load(open('keyed_features.json'));labdev=load_labels({'dev'})
 dr=[]
 for u in units:
  if u['part']=='dev':
   q=[labdev[n] for n in u['replicate_rownums'] if n in labdev]
   if q:z=dict(u,y=int(median(q)<80));dr.append(z)
 lab=load_labels({'test'});tr=[]
 for u in units:
  if u['part']!='test' or u['excluded']:continue
  q=[lab[n] for n in u['replicate_rownums'] if n in lab]
  if q:z=dict(u,endpoint=median(q),y=int(median(q)<80));tr.append(z)
 X=np.array([r['x'] for r in dr]);y=[r['y'] for r in dr];T=np.array([r['x'] for r in tr]);p=fitpred(X,y,T,dev['chosen_C']);ba=fitpred(X[:,[0,1]],y,T[:,[0,1]],dev['baselineA_C']);canon=json.load(open(SCHEMA))['order'].index('pair_canonical_fraction');bb=1-T[:,canon]
 prim,pd=macro(tr,p);ma,ad=macro(tr,ba);mb,bd=macro(tr,bb);puzzles=sorted(pd)
 if len(puzzles)<5:raise RuntimeError('endpoint-infeasible: fewer than five mixed-class puzzles')
 rng=np.random.default_rng(2019);boot=[];da=[];db=[]
 for _ in range(10000):
  q=rng.choice(puzzles,len(puzzles),replace=True);x=np.mean([pd[z] for z in q]);boot.append(x);da.append(x-np.mean([ad[z] for z in q]));db.append(x-np.mean([bd[z] for z in q]))
 # strata using dev cut
 strata={}
 for name,fn in [('short',lambda r:r['length']<=dev['length_cut']),('long',lambda r:r['length']>dev['length_cut'])]:
  ix=[i for i,r in enumerate(tr) if fn(r)];strata[name]=macro([tr[i] for i in ix],p[ix])[0]
 better=max(ma,mb);g={'auc':prim>=.75,'ci_lower':np.quantile(boot,.025)>=.65,'baseline_advantage':prim-better>=.05,'length_strata':all(v is not None and v>=.70 for v in strata.values()),'puzzle_direction':np.mean([v>.5 for v in pd.values()])>=.70};g['all']=all(g.values())
 unitsout=[];raw=[]
 for i,r in enumerate(tr):
  z={k:r[k] for k in ['key','puzzle','representative_id','length','endpoint','y','replicate_rownums']}|{'prediction':float(p[i]),'baselineA':float(ba[i]),'baselineB':float(bb[i]),'protocol_id':PROTOCOL,'lock_sha256':LOCK_SHA,'source_sha256':DATA_SHA};unitsout.append(z)
  for n in r['replicate_rownums']:raw.append({'rownum':n,'key':r['key'],'puzzle':r['puzzle'],'replicate_endpoint':lab.get(n),'unit_endpoint':r['endpoint'],'y':r['y'],'prediction':float(p[i]),'baselineA':float(ba[i]),'baselineB':float(bb[i]),'protocol_id':PROTOCOL,'lock_sha256':LOCK_SHA,'source_sha256':DATA_SHA})
 res={'protocol_id':PROTOCOL,'lock_sha256':LOCK_SHA,'source_sha256':DATA_SHA,'n_test_units':len(tr),'n_mixed_puzzles':len(puzzles),'primary_macro_auc':prim,'bootstrap_95_ci':[float(np.quantile(boot,.025)),float(np.quantile(boot,.975))],'baselineA_macro_auc':ma,'baselineB_macro_auc':mb,'advantage_A':prim-ma,'advantage_A_95_ci':[float(np.quantile(da,.025)),float(np.quantile(da,.975))],'advantage_B':prim-mb,'advantage_B_95_ci':[float(np.quantile(db,.025)),float(np.quantile(db,.975))],'length_strata':strata,'fraction_puzzles_auc_gt_half':float(np.mean([v>.5 for v in pd.values()])),'per_puzzle':pd,'gates':g}
 dump(unitsout,'test_unit_predictions.json');dump(raw,'test_raw_replicate_predictions.json');dump({'primary':boot,'minus_A':da,'minus_B':db},'bootstrap_10000.json');dump(res,'results.json');print('test_complete')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['meta','dev','test']);a=ap.parse_args();start=time.time();getattr(sys.modules[__name__],'phase_'+a.phase)();dump({'phase':a.phase,'wall_seconds':time.time()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'utc_end':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()},f'runtime_{a.phase}.json')
if __name__=='__main__':main()
