# DOC-2-019 R1 metadata and model-availability audit

**Audit date:** 22 September 2026 IST  
**Outcome firewall:** No experimental OpenKnot scores, RNet scores/structures, SHAPE reactivities, model perplexities, predicted screening scores, benchmark performance summaries, or classifier outcomes were read or computed. The audit script projects only identifiers, model/method, round, puzzle, assay type, design sequence, and the benchmark's prespecified assay-quality flag. `metadata_audit.json` records `outcome_fields_accessed: false`.

## Decision
**Feasible, conditional on adjudication of the attached prospective lock.** The named open model is gRNAde v1.0.0, commit `2453b18778a1981ac25f314790e5395f1e9ab218`, checkpoint repository revision `91491fc71584bf37fee8297781edf7df07b1d349`. The experimental benchmark is Eterna OpenKnot chemical mapping, repository commit `211a90e2b0dcc47d1a0325a6737e3b48bf76da52`, file `OpenKnotBench_data.v4.5.1.csv`, SHA-256 `22fa72df6d98f86fbf37a57e679f717628a5d5db3737df3f5519901bc9777901`.

## Named model availability
- gRNAde is a geometric RNA inverse-design model conditioned on target 3D coordinates and/or secondary structure.
- Code repository is public and MIT licensed. Pinned v1.0.0 code is downloadable and includes generation and evaluation entry points.
- Main checkpoint `gRNAde_drop3d@0.75_maxlen@500.h5` is public, ungated, 8,726,092 bytes, MIT-labeled, and directly downloadable.
- Independent screening checkpoints are also public: RibonanzaNet (45,406,126 bytes) and RibonanzaNet-SS (45,420,400 bytes). RhoFold is available but excluded from R1 to keep compute and dependence manageable.
- Official documented environment is Python 3.10, PyTorch 2.1 and PyTorch Geometric; CPU execution is documented, while A100 GPU is supported. Current task container does not yet contain PyTorch/PyG/Biotite, so environment setup is required after lock approval. This is an execution cost, not a data-access blocker.
- Published generation artifacts expose `sequence`, model, seed, temperature, perplexity, predicted OpenKnot score and RibonanzaNet-SS self-consistency. Forty 2D and forty 3D candidate CSVs are publicly indexed for 40 experimental puzzles.

## Experimental benchmark availability
- OpenKnot is a community/blinded RNA-design benchmark using 2A3-MaP SHAPE chemical mapping. The public table contains sequence, target structure, method, puzzle, round, read-quality metadata, experimental SHAPE profiles and experimental `target_openknot_score`.
- OpenKnot score is 0-100 and measures agreement of experimental SHAPE with the target, including a crossed-pair subscore. The benchmark maintainers state scores above 80 have a good chance of representing the intended pseudoknot. This supplies an externally defined failure threshold rather than a data-derived cutoff.
- The commit-pinned benchmark file is public under Apache-2.0 and is 139,830,358 bytes.
- Metadata-only count: 36,761 rows total. Exact method `gRNAde` has 1,424 rows across 51 puzzles and rounds 1-4, including 1,421 rows with valid unpadded design sequences. The benchmark quality flag is positive for 1,308 and negative for 116 gRNAde rows. `gRNAde-no3d` is separately labeled and will not be pooled with the primary named-model cohort.
- All records use 2A3-MaP. The file includes the necessary puzzle, round, model/method, unpadded sequence, target structure, and assay-quality fields.

## Leakage and provenance assessment
- **Experimental outcome is real:** SHAPE profiles were experimentally measured; the primary endpoint is not a folding-model proxy.
- **Selection is not population-representative:** submitted designs were screened before synthesis. R1 therefore estimates failure detection among submitted gRNAde designs, not all raw model samples.
- **Prospective-analysis, retrospective-data design:** assays already exist, but the outcome firewall and adjudicated lock precede any outcome inspection in this work.
- **Temporal split is available:** rounds 1-3 can be development data and round 4 a locked, later-round test. Puzzle IDs define grouping. No random row split is allowed.
- **Potential sequence duplicates:** exact-sequence deduplication across development/test is locked before outcomes. Test sequences matching any development sequence are excluded. Within-test duplicate sequences collapse to one unit using the median assay score, with puzzle retained; cross-puzzle duplicates are excluded rather than ambiguously assigned.
- **Detector features must predate assays:** only gRNAde generation-time quantities and sequence/target descriptors are allowed. No experimental field, benchmark RNet result, read count, signal-to-noise, SHAPE value, or assay-quality measure may be a predictor.
- **Assay quality is eligibility, not a feature:** primary analysis is restricted to `SN_filter=1`, defined by benchmark maintainers as signal-to-noise >1 and reads >100. Neither constituent is available to the detector.
- **Dependency caveat:** RibonanzaNet screening is part of the original gRNAde pipeline and may have influenced selection. Its score is useful as a realistic baseline, but detector improvement must be tested against it, not claimed independent of it.

## Audit verdict
The named model, checkpoint, code, generation metadata, experimental outcome, target grouping, assay-quality rule, and temporal rounds are all available. The design is scientifically feasible. The strongest honest claim is: **can a frozen pre-assay detector identify experimental target-structure failures among submitted designs from a named RNA generator in a later benchmark round?** It is not a universal detector and does not estimate performance on unscreened generations.

## Source URLs
- gRNAde code: https://github.com/chaitjo/geometric-rna-design
- gRNAde v1.0.0 release: https://github.com/chaitjo/geometric-rna-design/releases/tag/v1.0.0
- gRNAde checkpoint repository: https://huggingface.co/chaitjo/gRNAde
- gRNAde dataset/artifacts: https://huggingface.co/datasets/chaitjo/gRNAde_datasets
- gRNAde experimental paper: https://www.biorxiv.org/content/10.1101/2025.11.29.691298v2.full-text
- OpenKnot benchmark data: https://github.com/eternagame/OpenKnotAIDesignData
- OpenKnot score definition: https://github.com/eternagame/OpenKnotScore
- OpenKnot study: https://daslab.stanford.edu/assets/pdfs/Townley_Kladwang_Science_2026.pdf
