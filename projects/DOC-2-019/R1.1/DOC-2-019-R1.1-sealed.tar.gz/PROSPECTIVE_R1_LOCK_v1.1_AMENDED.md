# DOC-2-019 R1.1: amended prospective lock
## Pre-assay detection of experimentally observed failure from named RNA model gRNAde

**State:** Proposed for adjudication; unexecuted. This supersedes R1 v1 only if approved. R1 v1 is preserved as `PROSPECTIVE_R1_LOCK_v1_UNEXECUTED.md`.  
**Outcome firewall:** No `target_openknot_score`, SHAPE/reactivity, RNet result, model perplexity, or detector outcome has been read or computed. `outcome_fields_accessed=false`.  
**Lock date:** 22 September 2026 IST.

## 1. Endpoint orientation, frozen from official text
The outcome is the experimental `target_openknot_score`, not a model proxy. Two commit-pinned official sources establish orientation before outcome access:

1. OpenKnotScoreMATLAB commit `6d1c413baa571be06e8dbb1d3ea9a544c36083d4`, README lines 13-15: **"It goes from 0 to 100, with higher values more likely to be pseudoknots."** and **"A score above is 80 is estimated to have a pretty good chance for being a pseudoknot. RNA with score below 80 may also form pseudoknots -- its just that the SHAPE data cannot distinguish."** Source: https://raw.githubusercontent.com/eternagame/OpenKnotScoreMATLAB/6d1c413baa571be06e8dbb1d3ea9a544c36083d4/README.md ; pinned copy SHA-256 `f3969fdf78ffa4e3cf0be43e50780e24293f46c1d3cbc4499e7e325a27c38499`.
2. OpenKnotAIDesignData commit `211a90e2b0dcc47d1a0325a6737e3b48bf76da52`, README line 28: `target_openknot_score` is **"number between 0 and 100 that scores percentage agreement between design's SHAPE reactivity profile and the target structure"** and averages the full-target and crossed-pair subscores. Source: https://raw.githubusercontent.com/eternagame/OpenKnotAIDesignData/211a90e2b0dcc47d1a0325a6737e3b48bf76da52/README.md ; pinned copy SHA-256 `b24683b22dc193b4ecb9fb03e699536e13a9e9558e6facb36eafe0ca009b8ce1`.

Therefore **failure = score <80**, success = score >=80, and higher detector output means greater failure risk. Orientation will not be inferred from distributions.

## 2. Estimand and sources
Primary estimand: unweighted mean across evaluable round-4 puzzles of within-puzzle AUROC for ranking assay-group failures among exact `method = gRNAde` submissions, using a detector trained only on rounds 1-3. This estimates discrimination among submitted, assayed gRNAde designs, not raw generations or other models.

Immutable sources:
- gRNAde v1.0.0 code `2453b18778a1981ac25f314790e5395f1e9ab218`; checkpoint repository revision `91491fc71584bf37fee8297781edf7df07b1d349`; MIT.
- OpenKnot data commit `211a90e2b0dcc47d1a0325a6737e3b48bf76da52`; file `OpenKnotBench_data.v4.5.1.csv`; SHA-256 `22fa72df6d98f86fbf37a57e679f717628a5d5db3737df3f5519901bc9777901`; Apache-2.0.

## 3. Prediction unit and assay replicates
Normalize sequence by removing ASCII whitespace, uppercasing and T-to-U; normalize target by removing ASCII whitespace. Create the **prediction unit key before outcome access** as `(puzzle, normalized_design_sequence, normalized_target_structure)`.

- Retain every assay row as a replicate tied to the unit key.
- After unblinding, define one endpoint per unit as the median of all finite replicate `target_openknot_score` values. For even replicate counts use the arithmetic mean of the two central values after ascending numeric sort. This rule is frozen and not chosen from agreement.
- Unit metadata are taken from the lexicographically smallest UTF-8 `id`; IDs must be nonmissing. Ties are broken by the original zero-based CSV row number. All raw replicate IDs and row numbers are retained.
- Same puzzle and sequence with different normalized target structures are distinct units and are never collapsed.
- A round-4 normalized sequence that exactly matches any development normalized sequence is excluded from primary test, regardless of puzzle/target.
- A round-4 normalized sequence present in more than one round-4 puzzle is excluded from primary test.
- No outcome-based exclusions beyond finite score requirement.

Raw predictions will include every assay replicate plus its shared unit prediction, endpoint and unit key; unit-level evaluation gives replicates no extra weight.

## 4. Cohort and strict parser
Include exact `method=gRNAde`, `experiment_type=2A3_MaP`, `SN_filter=1`, rounds 1-4, nonmissing puzzle/id, and valid inputs.

Sequence parser: after normalization require length >=3 and only `A,C,G,U`. Target parser: same length; only `.()[]{}<>`; each opening symbol closes with its unique matching symbol; every symbol participates in exactly one pair; stack parsing occurs independently for each alphabet; a close without an available open, an unclosed open, or any other character rejects the row before endpoint access. Pair crossings are computed over all parsed pairs using `i<k<j<l` or `k<i<l<j`. A contiguous stem is a maximal set `(i+t,j-t)` for integer `t>=0`; each pair belongs to one stem. Runs use consecutive positions.

Schema control: exact required column names/types are asserted; extra columns are ignored. Input and source hashes are checked before parsing. Parser unit tests include valid nested, valid crossing, unbalanced close/open, illegal character, unequal length, no pairs and no unpaired positions. All must pass before labels load.

## 5. Frozen 120-feature map
The exact 120 names and order are in `feature_schema_v1.json`, incorporated by reference and sealed with this lock. Counts use overlapping k-mers and denominators `L-k+1`. Fractions over zero eligible items are zero and their named missingness flag is one. Entropy uses natural log and normalization by `log(4)`. Pair orientation follows ascending sequence index. `pk_bracket_pair_fraction` counts pairs encoded by `[]`, `{}`, or `<>`. Crossing-pair fraction counts unique pairs participating in at least one crossing divided by all pairs. Continuous infinities/NaNs are forbidden; there is no data-dependent imputation because every feature has a total definition. Standardization mean and population SD (`ddof=0`) are learned on each training fold; zero-SD columns map to zero. The four missingness flags are standardized like other columns.

Forbidden predictors: experimental score, SHAPE/reactivity, reads, signal-to-noise, SN_filter, RNet outputs, dataset name, round, puzzle, ID, assay replicate count, model perplexity, predicted OpenKnot score, or any post-assay quantity.

## 6. Deterministic development folds
Development is rounds 1-3; test is round 4. Sort unique development puzzle strings by UTF-8 byte order. Assign puzzle at sorted index `i` to fold `i mod 5`. This mapping is created from metadata before label load and saved as CSV with `puzzle,fold`; its SHA-256 is written into the run manifest.

After unblinding, every fold's validation partition and complementary training partition must each contain both endpoint classes at the unit level. If any fails, **endpoint-infeasible: stop with no model fit and no test outcome inspection**. Fold allocation is never repaired using labels.

## 7. Frozen models
Software execution environment: Python 3.10.12; NumPy 2.2.6; SciPy 1.15.3; pandas 2.3.3; scikit-learn **1.6.1** installed into an isolated environment and hash-locked before run. Package versions and wheels/hashes are recorded with `pip freeze` and `pip hash`/download manifest.

Primary: `sklearn.linear_model.LogisticRegression(penalty='l2', C=C, solver='liblinear', max_iter=5000, tol=1e-8, fit_intercept=True, intercept_scaling=1, class_weight=None, random_state=2019)`. Within each training fold, sample weight for class c is `n_train/(2*n_train_c)`. Grid `C=[0.01,0.1,1,10,100]`. Select highest mean unweighted puzzle-macro AUROC over five validation folds; exact numeric ties choose smaller C. Refit on all development units with the same class-weight formula.

Baseline A: identical process using only `length,gc_fraction`. Baseline B: fixed risk `1-pair_canonical_fraction`, unfitted. No other model or feature selection.

## 8. Evaluation and uncertainty
Primary is puzzle-macro AUROC among round-4 puzzles with both unit classes. Bootstrap seed 2019, 10,000 draws of puzzles with replacement. Each draw recomputes unweighted puzzle-macro AUROC.

For primary-minus-each-baseline, use the **same sampled puzzle indices per draw**, yielding paired difference distributions and percentile 95% CIs. Gate 3 requires only point improvement >=0.05 over the better point-estimate baseline. The paired lower CI is mandatory to report but **does not gate R1.1**; this choice is prospective and avoids adding an unpowered precision gate beyond Gate 2.

Length threshold is the median normalized sequence length of all eligible **development units**, calculated before test feature access. For even n it is arithmetic mean of central lengths. Test units with length <= threshold are short; > threshold long. No test median is used.

Descriptive only: pooled AUROC/AP, puzzle-macro AP, sensitivity/specificity at the development-OOF balanced-accuracy threshold (threshold ties choose largest numeric threshold), and pseudoknot-fraction strata using the analogous development-unit median. **Calibration and Brier score are dropped from R1.1** rather than underspecified.

## 9. Controls and fail-closed checks
Before test outcomes load:
- source hashes, schema and parser tests pass;
- fold-membership hash is sealed;
- feature count is exactly 120, order hash matches manifest, values finite;
- identical records produce identical feature vectors; row permutation produces identical keyed features;
- labels are not available to feature code.

After development labels load, before test outcomes:
- each fold class check passes;
- convergence is required for all 5x5 primary and baseline-A fits; any convergence warning is fatal;
- label-shuffle control: permute development labels within puzzle using seeds `2019000+j`, j=0..99, rerun primary CV at fixed selected C; mean puzzle-macro AUROC across shuffles must be 0.40-0.60 or run halts for audit. Shuffle results cannot tune the model.
- inversion control: AUROC of `-primary_score` must equal `1-AUROC(primary_score)` within `1e-12` on every mixed validation puzzle.

## 10. Feasibility and success gates
Pre-unblinding metadata gates: >=300 development and >=100 round-4 units; >=10 puzzles in each; >=90% parser yield. After development-label access, fold class checks must pass. After test unblinding, >=5 mixed-class round-4 puzzles or endpoint-infeasible.

Positive only if all hold:
1. primary puzzle-macro AUROC >=0.75;
2. 10,000-bootstrap 95% CI lower bound >=0.65;
3. point AUROC improvement >=0.05 over the better frozen baseline, with paired CIs reported but not gated;
4. AUROC >=0.70 in both strata cut by development median length;
5. >=70% of evaluable test puzzles have AUROC >0.50.

No secondary/transfer result rescues failure.

## 11. Compute and sealed outputs
Compute ceiling: 8 CPU cores, 32 GiB RSS, 6 wall-clock hours, 20 GiB local disk; no GPU required. Exceeding any ceiling stops the run and records infeasible/compute. Record per-stage UTC start/end, wall seconds, user/system CPU seconds, peak RSS KiB, input/output bytes and exit status in `runtime_ledger.json`.

Every JSON writer uses `allow_nan=False`. Every output record carries `protocol_id=DOC-2-019-R1.1`, lock SHA-256, source file SHA-256, model code/checkpoint revisions and run ID. Required outputs: package manifest with SHA-256/bytes/media type for every file; complete unit predictions; complete raw replicate prediction rows; exclusions; fold mapping; CV grid; shuffle controls; per-puzzle metrics; 10,000 bootstrap aggregates and paired differences; gates; package/environment manifests; stdout/stderr; runtime/RSS ledger. Negative and infeasible results are preserved.

At seal time, before completion is reported, create a deterministic tar archive; compute its SHA-256; upload immediately to **two independent durable destinations approved by the science orchestrator**; download/read back both copies; verify archive SHA and every internal manifest hash; record returned URLs/IDs, timestamps and verification in `durable_seal_receipts.json`. If two destinations or readback are unavailable, status is `complete-but-not-durably-sealed`, never fully complete.

## 12. Claim boundary and adjudication
Allowed positive claim: a frozen sequence/target-topology detector prospectively discriminated later-round experimental OpenKnot failures among submitted gRNAde designs. No claim of molecular function, causal mechanism, unscreened-model performance, universal hallucination detection or transfer beyond OpenKnot.

Approve, reject or amend R1.1 before outcome access. Any amendment creates a new version and SHA.
