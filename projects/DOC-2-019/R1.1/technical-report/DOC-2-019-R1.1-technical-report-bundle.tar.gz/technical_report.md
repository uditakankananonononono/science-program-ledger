---
title: "DOC-2-019 R1.1 technical report"
subtitle: "A prospective test of a pre-assay RNA model hallucination detector"
author: "Open-data computational biology program"
date: "22 September 2026"
geometry: margin=0.72in
fontsize: 10pt
colorlinks: true
linkcolor: "146b63"
urlcolor: "146b63"
---

# Executive summary

This report documents the complete technical design, execution, controls, and adjudicated interpretation of DOC-2-019 R1.1. The study tested whether a frozen detector based on RNA sequence and intended target topology could discriminate **OpenKnot scores below the external benchmark of 80** among submitted, assayed designs from the named open RNA model gRNAde.

The detector did not meet any of its five locked success gates. On 357 held-out round-4 prediction units across 15 puzzles with both endpoint classes, the primary puzzle-macro AUROC was **0.5238** (95% puzzle-bootstrap CI **0.3853-0.6657**). The frozen length+GC baseline scored 0.6236; the canonical-pair baseline scored 0.5547. The primary detector was worse than both.

The result is a useful negative. It rejects the proposed frozen feature set for this audit role under a temporal, puzzle-grouped experimental test. It does not establish molecular non-formation, does not show that gRNAde fails as a design system, and does not support universal claims about RNA-model hallucination.

**Study at a glance**

- **Named generator:** gRNAde v1.0.0.
- **Experimental benchmark:** Eterna OpenKnot, 2A3-MaP.
- **Development / test:** rounds 1-3 / round 4.
- **Endpoint:** OpenKnot score <80.
- **Prediction units:** 970 development; 357 test.
- **Primary result:** puzzle-macro AUROC 0.5238 (95% CI 0.3853-0.6657).
- **Gate verdict:** 0 of 5 passed; adjudicated useful negative.

# 1. Purpose and scope

## 1.1 Technical objective

The technical objective was to evaluate a fixed, pre-assay risk model under conditions that prevent family or puzzle leakage, post-outcome feature changes, threshold fishing, and rescue by favorable secondary analyses. The operational question was:

> Among experimentally assayed submissions labeled exactly `gRNAde`, can a detector using only the designed sequence and intended target secondary structure identify designs with an OpenKnot score below 80 in a later benchmark round?

The primary estimand was the unweighted mean of within-puzzle AUROCs across evaluable round-4 puzzles. The unit of external generalization was the puzzle, not the individual assay row.

## 1.2 Claim boundary

A below-80 endpoint is an **experimental score failure** relative to the external OpenKnot benchmark. Official documentation says the score runs from 0 to 100, higher values are more likely to represent pseudoknots, and a score above 80 has a good chance of doing so. It also says RNA below 80 may still form pseudoknots because SHAPE cannot distinguish them. The report therefore makes no molecular non-formation claim.

The study estimates performance among submitted, experimentally assayed gRNAde designs. Submission involved upstream screening. It is not a random sample of all raw model outputs.

# 2. Governance and prospective controls

## 2.1 Outcome firewall

Work proceeded in four sealed phases:

1. **Availability audit:** verify the named model, checkpoint, code, benchmark, experimental endpoint, metadata, licenses, and compute requirements without reading outcomes.
2. **Pre-label seal:** hash inputs; run parser and schema controls; create keyed features and deterministic puzzle folds; apply metadata gates.
3. **Development seal:** load rounds 1-3 labels only; verify class support; fit cross-validation models; run shuffle and inversion controls; freeze hyperparameters and cut points.
4. **Test unblinding:** load round-4 outcomes once; compute predictions, puzzle metrics, paired bootstrap intervals, and locked gates.

The approved lock SHA-256 was `ccd70bb8c47b34b33f1bbcfc00798e48cfdaa918131f6c84eb159624a0fe97b6`. The exact feature schema SHA-256 was `04bee8d4bbc448a0c45138c1820955836adb131fe8af6323e915d23f999e63d5`.

![Figure 1. Locked execution flow. Each seal preceded access to the next outcome layer.](tech_figure1_flow.png){width=94%}

## 2.2 Adjudication history

The initial prospective lock was amended before execution. The independent adjudicator required explicit endpoint orientation from official text, outcome-independent prediction-unit rules, deterministic folds, development-derived subgroup cuts, paired baseline uncertainty, a complete parser and feature specification, strict serialization, compute limits, and dual durable sealing. R1.1 incorporated every amendment before outcomes were accessed.

## 2.3 Stop rules

The run was required to stop as infeasible if metadata counts were insufficient, parser yield fell below 90%, a development fold lacked either class, fewer than five test puzzles contained both endpoint classes, a model emitted a convergence warning, the label-shuffle mean fell outside 0.40-0.60, or compute exceeded the ceiling. None of these stop conditions fired.

# 3. Sources and version control

## 3.1 Named model

The named model was gRNAde v1.0.0, a geometric RNA inverse-design model conditioned on target 3D coordinates and/or secondary structure.

- Code: `https://github.com/chaitjo/geometric-rna-design`
- Pinned commit: `2453b18778a1981ac25f314790e5395f1e9ab218`
- License: MIT
- Checkpoint repository: `https://huggingface.co/chaitjo/gRNAde`
- Checkpoint revision: `91491fc71584bf37fee8297781edf7df07b1d349`
- Main checkpoint: `gRNAde_drop3d@0.75_maxlen@500.h5`

The checkpoint was available without gating. R1.1 used the benchmark's named gRNAde submissions; it did not regenerate molecules.

## 3.2 Experimental benchmark

The source was Eterna OpenKnot AI Design Data.

- Repository: `https://github.com/eternagame/OpenKnotAIDesignData`
- Pinned commit: `211a90e2b0dcc47d1a0325a6737e3b48bf76da52`
- File: `Data/OpenKnotBench_data.v4.5.1.csv`
- File SHA-256: `22fa72df6d98f86fbf37a57e679f717628a5d5db3737df3f5519901bc9777901`
- License: Apache-2.0
- Experimental method: 2A3-MaP SHAPE chemical mapping

The commit-pinned file contained 36,761 rows. Metadata-only audit identified 1,424 exact `gRNAde` rows across 51 puzzles and rounds 1-4; 1,333 passed the benchmark's assay-quality filter.

# 4. Cohort construction

## 4.1 Row eligibility

Rows were eligible when all conditions held:

- method equaled `gRNAde` exactly;
- experiment type equaled `2A3_MaP`;
- `SN_filter=1`;
- round was 1, 2, 3, or 4;
- puzzle and ID were present;
- normalized sequence contained only A/C/G/U and had length at least three;
- target structure had the same length and passed the strict bracket parser.

`gRNAde-no3d` was kept separate and did not enter the primary cohort.

## 4.2 Normalization and parser

Sequences had ASCII whitespace removed, were uppercased, and T was mapped to U. Targets had whitespace removed and were restricted to `.()[]{}<>`. Each bracket alphabet was parsed with its own stack. Invalid closes, unclosed opens, illegal characters, and length mismatch rejected a row before outcome access.

Crossings used the conditions `i<k<j<l` or `k<i<l<j`. A contiguous stem was the maximal set `(i+t, j-t)`. Parser controls covered nested and crossing targets, malformed opens and closes, illegal symbols, unequal lengths, no-pair targets, and fully paired targets.

## 4.3 Prediction units and replicates

The unit key was a SHA-256 digest of `(puzzle, normalized design sequence, normalized target structure)`. This key was created before outcomes. Every assay replicate remained linked to its unit.

After outcome access, the unit endpoint was the median of finite replicate scores. For an even number of replicates, the two central values were averaged. Metadata came from the lexicographically smallest UTF-8 ID, with original CSV row number as tie-breaker. A sequence associated with a different target was never silently collapsed.

Round-4 sequences identical to a development sequence were excluded. Round-4 sequences appearing under more than one test puzzle were also excluded. These rules were outcome-blind.

## 4.4 Cohort flow

**Cohort flow**

- **Parsed units:** 970 development; 357 unexcluded test.
- **Puzzles:** 31 development; 20 test.
- **Parser yield:** 100% in both partitions.
- **Endpoint units:** 970 development; 357 test.
- **Class support:** every development fold valid; 15 mixed-class test puzzles.

Development included 365 score-failure units and 605 success units. The test set included 61 score-failure units and 296 success units.

# 5. Feature engineering

The feature vector had exactly 120 values in a sealed order. All values were deterministic from sequence and target structure; no experimental or post-assay field entered the detector.

## 5.1 Sequence features

- length and GC fraction;
- A/C/G/U fractions;
- normalized mononucleotide entropy;
- maximum homopolymer fraction and fraction of residues in runs at least four bases long;
- all 16 dinucleotide and 64 trinucleotide frequencies;
- CpG and UpA fractions.

Overlapping k-mers used denominator `L-k+1`. Entropy used natural logarithms and normalization by `log(4)`.

## 5.2 Target-topology features

- paired-residue and pair-density measures;
- pseudoknot-bracket fraction;
- fraction of pairs participating in crossings;
- maximum pairing span;
- stem count, mean stem length, and maximum stem length;
- mean and maximum unpaired-run length.

## 5.3 Sequence-target compatibility

- orientation-specific AU, UA, GC, CG, GU and UG pair fractions;
- canonical, noncanonical, GC-pair and wobble fractions;
- canonical and noncanonical fractions among crossing pairs;
- absolute paired-versus-unpaired GC difference;
- paired-position and unpaired-position entropy;
- explicit flags for no pairs, no crossing pairs, no unpaired positions, and no paired positions.

Undefined ratios were zero with the corresponding missingness flag set. NaN and infinity were forbidden. Standardization was learned on each training fold with population standard deviation; zero-variance columns mapped to zero.

## 5.4 Forbidden information

The model could not use OpenKnot score, SHAPE values, reads, signal-to-noise, `SN_filter`, RNet outputs, round, puzzle, ID, assay replicate count, model perplexity, predicted OpenKnot score, or any post-assay quantity.

# 6. Model development

## 6.1 Deterministic folds

Unique development puzzles were sorted by UTF-8 byte order. Puzzle at sorted index `i` was assigned to fold `i mod 5`. The fold map was sealed before labels with SHA-256 `5c1cbb37edb82191eb46a88323cbe6622d0773754167046c5221869a43a541d1`. Each validation fold and complementary training set contained both classes.

## 6.2 Primary detector

The primary model was scikit-learn 1.6.1 L2 logistic regression:

- solver `liblinear`;
- `max_iter=5000`;
- tolerance `1e-8`;
- intercept enabled;
- random state 2019;
- no library class-weight option;
- explicit sample weight `n / (2 n_c)` for class `c`.

Candidate C values were 0.01, 0.1, 1, 10 and 100. Selection maximized mean puzzle-macro AUROC across the five validation folds. Numeric ties selected smaller C.

## 6.3 Baselines

Baseline A used identical fitting and tuning but only length and GC fraction. Baseline B was fixed risk `1 - canonical target-pair fraction` and required no fitting.

## 6.4 Development readout

**Development grid**

- **C=0.01:** primary 0.6533; length+GC 0.6743.
- **C=0.1:** primary 0.6359; length+GC **0.6744**.
- **C=1:** primary 0.6467; length+GC 0.6744.
- **C=10:** primary 0.6458; length+GC 0.6744.
- **C=100:** primary **0.6534**; length+GC 0.6744.

The primary model selected C=100. Baseline A selected C=0.1 because ties choose the smaller C. The development median length cut was 88 nt. The sealed decision threshold for descriptive classification was 0.4461.

# 7. Quality controls

## 7.1 Pre-label controls

- all source, lock, and schema hashes matched;
- feature count was exactly 120 with unique names and fixed order;
- parser tests passed;
- keyed features were invariant to repeated calculation;
- every feature value was finite;
- row ordering did not define folds or units.

The keyed feature-map SHA-256 was `1df7fe4960a1107c538514b6ce0c955c6044c549e18d5321005c66f742c38981`.

## 7.2 Development-label controls

All 25 primary and baseline fits converged without warnings. For each validation fold, negating scores produced `1 - AUROC` within `1e-12` on every mixed-class puzzle.

The label-shuffle control permuted labels within puzzle for 100 seeds while holding selected C fixed. Mean puzzle-macro AUROC was **0.4965**, inside the locked 0.40-0.60 acceptance range.

![Figure 2. The within-puzzle label-shuffle control centered on chance.](tech_figure2_shuffle.png){width=76%}

## 7.3 Runtime and compute

**Runtime ledger**

- **Metadata / features:** 4.7 s; 229 MB peak RSS.
- **Development / controls:** 117.9 s; 160 MB.
- **Test / bootstrap:** 4.0 s; 159 MB.

The run remained far below the ceiling of 8 CPU cores, 32 GiB RSS, six hours, and 20 GiB local disk.

# 8. Locked test evaluation

## 8.1 Primary result

Fifteen round-4 puzzles contained both endpoint classes. The primary puzzle-macro AUROC was **0.5238**. The 10,000-draw puzzle-cluster bootstrap 95% interval was **0.3853-0.6657**.

Puzzle AUROCs ranged from 0.0882 to 1.0000. Six of fifteen puzzles had AUROC above 0.50, yielding the locked directional fraction of 40%.

![Figure 3. Within-puzzle AUROC on the no-touch round-4 test.](figure1_puzzle_auc.png){width=91%}

## 8.2 Baseline comparison

**Baseline comparison**

- **Primary detector:** AUROC 0.5238; bootstrap interval 0.3853 to 0.6657.
- **Length + GC:** AUROC 0.6236; primary difference -0.0997 (paired CI -0.2188 to 0.0120).
- **Canonical target pairs:** AUROC 0.5547; primary difference -0.0308 (paired CI -0.2324 to 0.1575).

The same resampled puzzle indices were used for each paired bootstrap difference.

![Figure 4. The primary detector did not beat either frozen baseline.](figure2_aggregate.png){width=78%}

## 8.3 Gate audit

**Gate audit**

- **Discrimination:** 0.5238 vs AUROC >=0.75 - **fail**.
- **Precision:** 0.3853 vs lower bound >=0.65 - **fail**.
- **Added value:** -0.0997 vs improvement >=0.05 - **fail**.
- **Length robustness:** long 0.5238, short unevaluable vs both >=0.70 - **fail**.
- **Puzzle direction:** 40% vs >=70% above 0.50 - **fail**.

All five gates failed. The short stratum contained no puzzle with both endpoint classes. Under the approved fail-closed rule, an undefined stratum cannot pass and is not replaced by pooled AUROC.

# 9. Same-spec repairs after test access

Three code failures occurred after the first test-outcome load. Each was recorded before repair.

1. **Fix 001:** the gate renderer attempted `min(None, float)` because the short stratum had no mixed-class puzzle. The repair implemented the locked requirement unchanged: a stratum must be defined and at least 0.70; otherwise the gate is false.
2. **Fix 002:** strict JSON serialization rejected NumPy boolean scalars. The writer was changed to convert NumPy scalars with `.item()` while preserving `allow_nan=False`.
3. **Fix 003:** a redundant console-only pretty-print used the standard encoder and rejected the same NumPy boolean. It was replaced by a fixed completion token.

No feature, parser, cohort, label, model, hyperparameter, threshold, prediction, metric, interval, or gate changed. Prediction and bootstrap file hashes were stable across serialization repairs. Independent adjudication accepted all three as same-spec repairs and rejected any post-hoc rescue.

# 10. Interpretation

## 10.1 What the result supports

The frozen sequence/topology detector did not discriminate OpenKnot scores below 80 among submitted, assayed gRNAde designs in round 4. Richer handcrafted features did not add value over simple baselines and did not generalize across later puzzles.

The study also validates a research process: explicit endpoint meaning, source pinning, prediction units fixed before outcomes, temporal separation, group-aware estimation, predeclared gates, negative-result preservation, and exact artifact sealing.

## 10.2 What the result does not support

It does not show that:

- gRNAde fails as an RNA-design system;
- any individual molecule failed to form a pseudoknot;
- OpenKnot score is direct structural proof;
- sequence/topology detectors can never work;
- the result transfers to unscreened generations, other models, other assays, or other RNA tasks;
- hallucination detection is impossible in RNA design.

## 10.3 Likely sources of difficulty

The study was not designed to adjudicate mechanisms, but several factors may explain weak discrimination:

- handcrafted summaries may omit the geometry and uncertainty relevant to experimental realization;
- submission screening may narrow the range of candidate quality;
- puzzle heterogeneity may dominate global sequence signatures;
- target topology alone may not capture tertiary interactions, ligand state, or ensemble behavior;
- the endpoint includes experimental and interpretive uncertainty.

These are hypotheses for a new lock, not post-hoc explanations that alter R1.1.

# 11. Recommended successor design

A successor should change the information set, not retune R1.1. A strong R2 would:

- include multiple named RNA generators;
- preserve model-held-out and puzzle-held-out test axes;
- use raw generation-time uncertainty or token logits;
- add target 3D geometry and folding-ensemble disagreement;
- retain independent experimental endpoints;
- preregister calibration, abstention, and decision-curve utility;
- benchmark against length, GC, canonical pairing, and model confidence;
- preserve a later prospective round whenever possible.

A separate mechanistic study could test why length+GC generalized better. It should lock hypotheses and analyses before opening any new outcomes.

# 12. Reproducibility and durable seal

The sealed analysis archive SHA-256 is:

`4521bfcb93228a4e4a745fa5f732effedf05d1d9fef43071b41914ac8c394a33`

Its 31-file internal manifest was verified with zero mismatches. The archive includes the approved lock, feature schema, acquisition manifest, metadata audit, full pipeline, pre-label manifest, fold map, keyed features, development seal, OOF predictions, test unit predictions, raw assay-replicate prediction rows, all 10,000 bootstrap draws, gate table, environment freeze, wheel hashes, runtime ledger, logs, and repair records.

The archive is intentionally referenced rather than duplicated in this technical-report bundle. It was read back byte-identically from two independent durable copies:

- private Google Drive file ID `17D6ZCHvTvjW6p8u9gIJET43Wm3feh--x`;
- repository commit `67d7effc8c4915a27c3f69b5cb00a33d8c0eeb09`.

The research paper was separately sealed in repository commit `efe2bda` and private Drive. This technical report is the interpretive and operational companion to that paper and the analysis archive.

# 13. File-hash register

**Hash register**

- Approved lock: `ccd70bb8...fe97b6`; feature schema: `04bee8d4...e63d5`.
- Source benchmark: `22fa72df...77901`; fold map: `5c1cbb37...541d1`.
- Keyed features: `1df7fe49...38981`; development seal: `9ede73d4...9994f`.
- Final results: `4ff017a3...127d50`; unit predictions: `b4b3ce7f...251413`.
- Raw replicates: `a08dfae3...2f750`; bootstrap draws: `e972a230...27088`.
- Sealed analysis archive: `4521bfcb...94a33`.

# 14. Conclusion

DOC-2-019 R1.1 is a complete, prospective, experimentally grounded negative result. The detector did not meet the discrimination, precision, added-value, subgroup, or puzzle-direction gates. The correct outcome is to retire this frozen detector specification, preserve the evidence, and treat any richer successor as a new study with a new lock.

# Source links

- gRNAde code: <https://github.com/chaitjo/geometric-rna-design>
- gRNAde checkpoint repository: <https://huggingface.co/chaitjo/gRNAde>
- gRNAde dataset/artifacts: <https://huggingface.co/datasets/chaitjo/gRNAde_datasets>
- OpenKnot data: <https://github.com/eternagame/OpenKnotAIDesignData>
- OpenKnot score definition: <https://github.com/eternagame/OpenKnotScoreMATLAB>
- Experimental gRNAde paper: <https://www.biorxiv.org/content/10.1101/2025.11.29.691298v2.full-text>
