# DOC-2-032 R1 metadata-only audit

Audit time: 2026-09-22 20:10 IST. No expression matrix values were inspected.

Candidate: AdamsonWeissman2016_GSM2406677_10X005.h5ad, Zenodo 7041849.
Shape: 15,006 cells x 32,738 genes.
Controls identified from labels: `3x_neg_ctrl_pMJ144-1` (1,715 cells) and `3x_neg_ctrl_pMJ144-2` (1,650), total 3,365. The literal `*` label has 13 cells and is not used as control.
Eligible non-control conditions at >=50 cells: YIPF5 plus ATF6_IRE1, ATF6_PERK_IRE1, ATF6_PERK, ATF6_only, IRE1_only, PERK_IRE1, PERK_only = 8.

Conclusion: candidate passes the pre-existing sample-size arms of F0 (>=200 controls; >=8 perturbations with >=50 cells). The gene arm (>=1,000 genes detected in >=20 cells) requires reading binary detection patterns and is reserved for the locked run. Proceed to an R1 protocol lock before any expression outcomes.
