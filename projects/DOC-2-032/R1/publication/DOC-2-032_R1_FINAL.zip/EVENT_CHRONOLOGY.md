# Immutable event chronology

Times are Asia/Calcutta (IST, UTC+05:30). Hashes identify the immutable file created at each event. Original event hashes were captured in `ORIGINAL_EVENT_HASHES.sha256` before the reproducibility rerun.

1. 2026-09-22 20:09:51.383 IST - metadata-only audit written, before expression access. `R1_METADATA_AUDIT.md`, SHA-256 `c83395b26f7601d731c6494c74e5d7a8ea1d57200485333c2e1a8c4f3ab65985`.
2. 2026-09-22 20:10:02.439 IST - R1 protocol locked. `R1_LOCKED_PROTOCOL.md`, SHA-256 `06e65fee7d0cae58b7d13a42f131967d96cc6af09b80a58efd0c6431b7ea714b`.
3. 2026-09-22 20:10:18.775 IST - locked analysis program written. `run_r1.py`, SHA-256 `98b19da415d4b59e39693142c6f3ed95c8c55d8367455f332c86fcfbccc4fcd1`.
4. 2026-09-22 20:10:27.835 IST - metric rows completed. Original `R1_metrics.csv`, SHA-256 `ae42f56ff67945907a9511f347a1615c95dea1414db77afaafe543be2b7fc7ac`.
5. 2026-09-22 20:10:27.895 IST - strict summary completed. Original `R1_summary.json`, SHA-256 `3905cc7963fd6eafe7ec6452b0f44c2efa2223a9c3b3fb270efc1ae7a130802f`.
6. 2026-09-22 20:10:47.135 IST - result report written. `R1_REPORT.md`, SHA-256 `bf0bc6e4ad2d46789c74c6e6d534f0ae6826d144444a75ad3ae6609ec6d615e0`.
7. Packaging phase - a timed clean rerun reproduced the summary and metrics byte-for-byte; hashes are in `REPRODUCTION_HASHES.sha256`. Runtime is in `analysis_runtime.json`.
