# DOC-2-032 R1 result

Verdict: **negative under the locked overall gate, with a strong primary signal**.

The larger, metadata-audited Adamson GSM2406677 sample passed F0. All 8 eligible perturbations were metric mirages in both cell half-splits: absolute-expression correlations ranged 0.978-0.997 even though the no-response predictor captured none of the perturbation direction. Pooled metric-mirage prevalence was 100% (16/16 split-condition evaluations), Wilson 95% lower bound 0.806. Labels agreed 100%; median absolute split change in correlation was 0.00119.

Exact gate results:
- F0 PASS: 8 eligible perturbations, 3,365 controls, 2,000 analysis genes.
- S1 PASS: 100% prevalence in each split; Wilson lower bound 80.6% >10%.
- S2 PASS: 100% agreement; median correlation change 0.00119 <=0.03.
- S3 FAIL: only one taxonomy class was occupied.
- Overall FAIL because all four gates were required.

Interpretation: conventional absolute-expression correlation can be nearly perfect for a predictor that predicts no perturbation response at all. This is a sharp and reproducible metric-mirage result. But the locked R1 was designed as a cartography study, and one deliberately weak baseline occupied only one failure class. It establishes the metric pathology, not a multi-class failure map. A grant-defensible next phase should retain this result as the motivating theorem-like counterexample and compare several real virtual-cell models across external datasets to populate and explain multiple failure regimes.

Source: https://zenodo.org/records/7041849
