# DOC-2-032 Virtual Cell Failure Cartography - R1 locked protocol

Lock timestamp: 2026-09-22 20:11 IST, after metadata-only reconnaissance and before inspecting expression values.

## Aim
Estimate how often absolute-expression accuracy creates a metric mirage: apparently excellent whole-profile reconstruction paired with failure to recover the perturbation-response direction. This is a failure-cartography estimand, not a model leaderboard.

## Data and units
Open scPerturb-harmonized Adamson et al. 2016 GSM2406677_10X005, Zenodo 7041849. Control pool is the union of labels `3x_neg_ctrl_pMJ144-1` and `3x_neg_ctrl_pMJ144-2`. Exclude `*` and all conditions with <50 cells. Unit is an eligible perturbation condition. Normalize each cell to 10,000 total counts and log1p. Genes must be detected in >=20 cells; select up to 2,000 genes with highest variance in controls only.

## Predictor and split
No-response baseline: predicted perturbed pseudobulk equals control pseudobulk. Perform two deterministic within-condition half-splits, seed 32032. This baseline is deliberately weak: the experiment tests whether a conventional metric hides a known response failure.

## Metrics and primary estimand
For each perturbation and split:
- `r_abs`: Pearson correlation of predicted and observed absolute mean expression.
- `top50_sign`: fraction of top 50 genes by absolute observed response with a matching nonzero predicted-response sign; zeros count wrong.
- `relative_response_norm`: norm(predicted response)/norm(observed response).

Metric mirage: `r_abs >= 0.90` and `top50_sign <= 0.55`.
Primary estimand: prevalence of metric mirages among eligible perturbations.

Taxonomy, priority order:
1. metric mirage;
2. transparent collapse: `r_abs <0.90` and `relative_response_norm <=0.25`;
3. other directional failure: `top50_sign <=0.55`;
4. directionally adequate: `top50_sign >0.55`.

## Locked gates
- F0: >=8 eligible perturbations, >=200 pooled control cells, >=1,000 eligible genes.
- S1: metric-mirage prevalence >=25% in each half-split and pooled Wilson 95% lower bound >10%.
- S2: label agreement between half-splits >=80%, and median absolute split change in r_abs <=0.03.
- S3: >=2 occupied taxonomy classes in either split.
- Overall pass requires F0 + S1 + S2 + S3.

No threshold changes, dataset substitution, or new success gates after expression access. Sensitivities at top-k 25/100 are descriptive only.
