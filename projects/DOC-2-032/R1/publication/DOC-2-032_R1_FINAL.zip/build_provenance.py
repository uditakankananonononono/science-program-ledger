import h5py,numpy as np,scipy.sparse as sp,hashlib,json,platform,sys,os
from pathlib import Path
FN='AdamsonWeissman2016_GSM2406677_10X005.h5ad';SEED=32032
with h5py.File(FN,'r') as f:
 shape=tuple(map(int,f['X'].attrs['shape'])); X=sp.csc_matrix((f['X/data'][:],f['X/indices'][:],f['X/indptr'][:]),shape=shape).tocsr().astype(float)
 cats=np.array([x.decode() for x in f['obs/perturbation/categories'][:]]);labels=cats[f['obs/perturbation/codes'][:]]
 genes=np.array([x.decode() for x in f['var/gene_symbol'][:]])
 bar=np.array([x.decode() for x in f['obs/cell_barcode'][:]])
controls=['3x_neg_ctrl_pMJ144-1','3x_neg_ctrl_pMJ144-2'];ctrl=np.where(np.isin(labels,controls))[0]
s=np.asarray(X.sum(1)).ravel(); X=sp.diags(np.divide(1e4,s,out=np.zeros_like(s),where=s>0))@X;X.data=np.log1p(X.data)
elig=np.asarray((X>0).sum(0)).ravel()>=20;m=np.asarray(X[ctrl].mean(0)).ravel();m2=np.asarray(X[ctrl].power(2).mean(0)).ravel();v=m2-m*m
ix=np.where(elig)[0];ix=ix[np.argsort(v[ix],kind='stable')[-min(2000,len(ix)):]]
Path('ordered_gene_panel.txt').write_text('\n'.join(genes[ix])+'\n')
def split(ids,key,h):
 z=ids.copy();r=np.random.default_rng(SEED+int(hashlib.sha256(key.encode()).hexdigest()[:8],16));r.shuffle(z);return z[h::2]
u,c=np.unique(labels,return_counts=True); counts=dict(zip(u,c)); perts=[p for p in u if p not in controls and p!='*' and counts[p]>=50]
mem={}
for q in controls+perts:
 ids=np.where(labels==q)[0]
 mem[q]={}
 for h in [0,1]:
  b=sorted(bar[split(ids,q,h)].tolist()); mem[q][f'half_{h+1}']={'n':len(b),'sha256_sorted_barcodes':hashlib.sha256(('\n'.join(b)+'\n').encode()).hexdigest()}
prov={'schema_version':'1.0.0','study_id':'DOC-2-032-R1','seed':SEED,'dataset':{'record_url':'https://zenodo.org/records/7041849','download_url':'https://zenodo.org/api/records/7041849/files/AdamsonWeissman2016_GSM2406677_10X005.h5ad/content','filename':FN,'bytes':139059637,'license':'CC-BY-4.0','zenodo_md5':'8657391920e7f8b3e6fd52745777002a','local_sha256':hashlib.sha256(Path(FN).read_bytes()).hexdigest()},'control_label_mapping':{'included':controls,'excluded_literal_star':True,'pooled_n':len(ctrl)},'eligible_perturbations':perts,'normalization':{'input_sparse_format':'H5AD CSC','materialized_as':'SciPy CSR float64 full matrix','per_cell_total_target':10000,'transform':'log1p','zero_total_handling':'scale factor 0','gene_detection_filter':'>=20 cells globally','feature_selection':'top 2000 variance among pooled control cells; uses all control cells before split'},'ordered_gene_panel':{'path':'ordered_gene_panel.txt','n':len(ix),'sha256':hashlib.sha256(Path('ordered_gene_panel.txt').read_bytes()).hexdigest()},'split_membership':mem,'environment':{'python':sys.version.split()[0],'platform':platform.platform(),'numpy':np.__version__,'scipy':__import__('scipy').__version__,'h5py':h5py.__version__},'claim_boundary':['no-response baseline counterexample','not a real virtual-cell-model evaluation','not multi-class failure cartography']}
Path('provenance.json').write_text(json.dumps(prov,indent=2,sort_keys=True)+'\n')
