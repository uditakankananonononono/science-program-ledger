# Dataset provenance

- Record: https://zenodo.org/records/7041849
- Direct file: https://zenodo.org/api/records/7041849/files/AdamsonWeissman2016_GSM2406677_10X005.h5ad/content
- File: `AdamsonWeissman2016_GSM2406677_10X005.h5ad`
- Size: 139,059,637 bytes
- License: Creative Commons Attribution 4.0 (CC-BY-4.0)
- Zenodo MD5: `8657391920e7f8b3e6fd52745777002a`
- Local SHA-256: `6c6eca0f53f8887b86597e2a4ff512ff2b2d3d9c78ee7deec9a6e7d6ae859d01`
- Original study: Adamson et al., Cell 2016, https://doi.org/10.1016/j.cell.2016.11.048
- Harmonized resource: scPerturb, https://doi.org/10.1038/s41592-023-02144-y

The H5AD bytes are not included in the portable artifact ZIP because the source file is 139 MB. Raw-expression metrics cannot be regenerated from the package alone. Download the exact file, verify both hashes, place it beside `run_r1.py`, and then run the validator and analysis.
