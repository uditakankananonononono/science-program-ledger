#!/usr/bin/env python3
import h5py,numpy as np,pandas as pd,scipy.sparse as sp,json,hashlib,math
from pathlib import Path
FN='AdamsonWeissman2016_GSM2406677_10X005.h5ad'; SEED=32032
with h5py.File(FN,'r') as f:
 shape=tuple(map(int,f['X'].attrs['shape'])); X=sp.csc_matrix((f['X/data'][:],f['X/indices'][:],f['X/indptr'][:]),shape=shape).tocsr().astype(float)
 cats=np.array([x.decode() for x in f['obs/perturbation/categories'][:]]); labels=cats[f['obs/perturbation/codes'][:]]
controls=['3x_neg_ctrl_pMJ144-1','3x_neg_ctrl_pMJ144-2']; ctrl=np.where(np.isin(labels,controls))[0]
u,c=np.unique(labels,return_counts=True); counts=dict(zip(u,c)); perts=[p for p in u if p not in controls and p!='*' and counts[p]>=50]
s=np.asarray(X.sum(1)).ravel(); X=sp.diags(np.divide(1e4,s,out=np.zeros_like(s),where=s>0))@X; X.data=np.log1p(X.data)
elig=np.asarray((X>0).sum(0)).ravel()>=20;m=np.asarray(X[ctrl].mean(0)).ravel();m2=np.asarray(X[ctrl].power(2).mean(0)).ravel();v=m2-m*m
ix=np.where(elig)[0];ix=ix[np.argsort(v[ix],kind='stable')[-min(2000,len(ix)):]]
def split_ids(ids,key,h):
 z=ids.copy(); r=np.random.default_rng(SEED+int(hashlib.sha256(key.encode()).hexdigest()[:8],16));r.shuffle(z);return z[h::2]
def corr(a,b):
 a=a-a.mean();b=b-b.mean();d=np.linalg.norm(a)*np.linalg.norm(b);return float(a@b/d) if d else float('nan')
rows=[]
for h in [0,1]:
 ci=np.concatenate([split_ids(np.where(labels==q)[0],q,h) for q in controls]); base=np.asarray(X[ci][:,ix].mean(0)).ravel()
 for p in perts:
  ids=split_ids(np.where(labels==p)[0],p,h); y=np.asarray(X[ids][:,ix].mean(0)).ravel(); resp=y-base;r=corr(base,y);top=np.argsort(np.abs(resp))[-50:];sg=float(np.mean((np.sign(np.zeros(50))==np.sign(resp[top]))&(np.sign(resp[top])!=0)));rel=0.
  lab='metric_mirage' if r>=.9 and sg<=.55 else ('transparent_collapse' if r<.9 and rel<=.25 else ('other_directional_failure' if sg<=.55 else 'directionally_adequate'))
  rows.append(dict(half=h+1,perturbation=p,n_cells=len(ids),r_abs=r,top50_sign=sg,relative_response_norm=rel,taxonomy=lab))
df=pd.DataFrame(rows);df.to_csv('R1_metrics.csv',index=False);w=df.pivot(index='perturbation',columns='half',values=['r_abs','taxonomy']);agree=float(np.mean(w.taxonomy[1]==w.taxonomy[2]));md=float(np.median(np.abs(w.r_abs[1].astype(float)-w.r_abs[2].astype(float))));prev=[float(np.mean(df[df.half==h].taxonomy=='metric_mirage')) for h in [1,2]];k=int(np.sum(df.taxonomy=='metric_mirage'));n=len(df);z=1.95996398454;ph=k/n;lo=(ph+z*z/(2*n)-z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n)))/(1+z*z/n);classes=sorted(df.taxonomy.unique());f0=len(perts)>=8 and len(ctrl)>=200 and len(ix)>=1000;s1=min(prev)>=.25 and lo>.10;s2=agree>=.8 and md<=.03;s3=len(classes)>=2
out=dict(cells=shape[0],genes=shape[1],control_cells=len(ctrl),eligible_perturbations=len(perts),analysis_genes=len(ix),prevalence=prev,wilson95_lower=lo,label_agreement=agree,median_abs_r_change=md,classes=classes,gates={'F0':f0,'S1':s1,'S2':s2,'S3':s3,'overall':f0 and s1 and s2 and s3});Path('R1_summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));print(df.to_string(index=False))
