import json,csv,hashlib,sys
from pathlib import Path
errors=[]
def req(cond,msg):
 if not cond: errors.append(msg)
s=json.loads(Path('R1_summary.json').read_text());p=json.loads(Path('provenance.json').read_text())
req(set(s)=={'cells','genes','control_cells','eligible_perturbations','analysis_genes','prevalence','wilson95_lower','label_agreement','median_abs_r_change','classes','gates'},'summary keys not strict')
req(all(isinstance(s[k],int) for k in ['cells','genes','control_cells','eligible_perturbations','analysis_genes']),'count types')
req(s['gates']=={'F0':True,'S1':True,'S2':True,'S3':False,'overall':False},'gate vector')
req(s['prevalence']==[1.0,1.0] and abs(s['wilson95_lower']-0.8063923194655722)<1e-12,'primary result')
rows=list(csv.DictReader(open('R1_metrics.csv')));req(len(rows)==16,'metric row count');req(len({r['perturbation'] for r in rows})==8,'pert count');req({r['half'] for r in rows}=={'1','2'},'halves');req(all(r['taxonomy']=='metric_mirage' for r in rows),'taxonomy')
genes=Path('ordered_gene_panel.txt').read_bytes();req(len(Path('ordered_gene_panel.txt').read_text().splitlines())==2000,'gene count');req(hashlib.sha256(genes).hexdigest()==p['ordered_gene_panel']['sha256'],'gene hash')
req(p['dataset']['local_sha256']=='6c6eca0f53f8887b86597e2a4ff512ff2b2d3d9c78ee7deec9a6e7d6ae859d01','dataset hash')
for q,h in p['split_membership'].items(): req(all(x['n']>0 and len(x['sha256_sorted_barcodes'])==64 for x in h.values()),'split '+q)
Path('VALIDATION.txt').write_text(('PASS\n' if not errors else 'FAIL\n'+'\n'.join(errors)+'\n'))
if errors: print(errors);sys.exit(1)
print('PASS: strict summary, 16 rows, gates, hashes, panel, and split manifests validated')
