DOC-2-032 R1 final package

Primary deliverables
- DOC-2-032_Research_Paper.docx / .pdf
- DOC-2-032_Technical_Report.docx / .pdf

Audit and reproduction
- R1_METADATA_AUDIT.md, R1_LOCKED_PROTOCOL.md, EVENT_CHRONOLOGY.md
- run_r1.py, build_provenance.py, validate_package.py
- R1_metrics.csv, R1_summary.json, provenance.json, ordered_gene_panel.txt
- analysis_runtime.json, provenance_runtime.json, validator_console.txt, VALIDATION.txt
- ORIGINAL_EVENT_HASHES.sha256 and REPRODUCTION_HASHES.sha256
- DATASET_PROVENANCE.md and ENVIRONMENT.md

The raw 139,059,637-byte H5AD is excluded. Raw-expression metrics cannot be regenerated from this ZIP alone. Download the exact CC-BY-4.0 file from the URL in DATASET_PROVENANCE.md and verify its hashes.

Typography: the editable documents and PDFs use Tinos, an OFL-licensed, metrically compatible Times New Roman face, because Microsoft's proprietary Times New Roman files were unavailable on the rendering host. All prose, tables, captions, headers, footers, and figures use this Times-compatible face. PDFs were rendered and visually inspected page by page.
