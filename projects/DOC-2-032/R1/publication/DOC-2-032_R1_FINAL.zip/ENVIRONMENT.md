# Environment and computational behavior

- Linux x86_64, kernel 6.1.158
- Python 3.10.12
- numpy 2.2.6; pandas 2.3.3; scipy 1.15.3; h5py 3.16.0
- Locked analysis timed clean rerun: 8.768 s elapsed; 6.163 s user; 1.978 s system; maximum RSS 1,634,896 KiB.
- Provenance builder: 7.831 s elapsed; maximum RSS 1,617,744 KiB.

The program reads the H5AD CSC arrays, materializes the complete matrix as float64 SciPy CSR, normalizes each cell to 10,000 total counts, and applies log1p to nonzero entries. Zero-total cells receive scale factor zero. Gene detection >=20 cells is evaluated globally. The top 2,000 panel is selected by variance computed over the pooled control cells before cell splitting. This control-only feature selection uses both eventual control halves and may make split-to-split stability slightly optimistic; it does not use perturbation labels to rank features. The claim is therefore restricted to this dataset-level counterexample and not out-of-sample model performance.
