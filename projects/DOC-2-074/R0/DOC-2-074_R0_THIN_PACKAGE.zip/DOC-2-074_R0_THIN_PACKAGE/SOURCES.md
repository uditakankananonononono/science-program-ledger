# Source ledger
- Official previous-release index: https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/ (release directories, LICENSE, README).
- Release 2023_01 root/release notes: https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/release-2023_01/ and https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/release-2023_01/relnotes.txt
- Release 2023_01 KB archive: https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/release-2023_01/knowledgebase/
- Release 2023_05 release notes and KB archive: https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/release-2023_05/relnotes.txt and https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/release-2023_05/knowledgebase/
- 2023_05 Swiss-Prot statistics: https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/release-2023_05/knowledgebase/UniProtKB_SwissProt-relstat.html
- Official license: https://www.uniprot.org/help/license and archive LICENSE.
