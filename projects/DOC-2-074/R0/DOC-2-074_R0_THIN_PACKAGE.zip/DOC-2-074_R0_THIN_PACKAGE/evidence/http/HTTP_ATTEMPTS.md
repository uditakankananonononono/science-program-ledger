# Runtime/HTTP evidence

Official metadata reads were attempted only. No archive payload was downloaded and no accession-level transition was inspected.

- `web_fetch` succeeded for the archive README, LICENSE, 2023_01 release notes/index and 2023_01 metalink metadata page.
- `web_fetch` timed out for several 2023_05 and TrEMBL statistics metadata pages.
- Direct `curl -I`/`wget` requests to large archive URLs returned no usable headers/content inside 20-second request bounds.
- Search-index excerpts were used only to document official directory listings and rounded sizes; rounded sizes were not treated as exact bytes or hashes.

This is transport evidence, not proof that the official host is generally unavailable.
