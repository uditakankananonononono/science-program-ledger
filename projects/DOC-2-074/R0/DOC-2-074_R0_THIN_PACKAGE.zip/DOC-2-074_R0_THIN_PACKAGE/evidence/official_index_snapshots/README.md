# Official index snapshots

These are compact, metadata-only snapshots transcribed from official UniProt archive index/search responses observed on 2026-09-22. URLs are retained for independent readback.

- Previous releases root: https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/
  - LICENSE, last modified 2023-09-13, displayed size 384 B.
  - README, last modified 2021-04-07, displayed size 3.5 KB.
  - Release directories include release-2023_01 and release-2023_05.
- Release 2023_01 root: https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/release-2023_01/
  - RELEASE.metalink displayed at 1.9 KB; changes.html 5.5 KB; knowledgebase directory; news.html 5.4 MB; relnotes.txt 1.0 KB.
  - Release notes date: 1 March 2023.
- Release 2023_05 knowledgebase: https://ftp.uniprot.org/pub/databases/uniprot/previous_releases/release-2023_05/knowledgebase/
  - Swiss-Prot release statistics state 570,420 sequences and 280,018 revised annotations; release date 8 November 2023.
- Scale anchors from official indexes:
  - release-2018_07 complete knowledgebase archive: displayed size 71 GB.
  - release-2026_01 complete knowledgebase archive: displayed size 151 GB; Swiss-Prot-only 1.6 GB; docs-only 392 MB.

Displayed sizes are rounded directory-index values, not exact content lengths. No SHA was claimed for the archive payloads.
