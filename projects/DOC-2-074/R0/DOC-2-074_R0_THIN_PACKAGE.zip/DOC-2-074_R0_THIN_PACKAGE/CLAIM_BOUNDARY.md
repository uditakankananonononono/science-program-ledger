# Claim boundary

DOC-2-074 R0 is a useful source/transport negative under this lane's approximately 2 GB ephemeral environment only.

The required historical unreviewed population is distributed through official complete UniProtKB archives that are tens to more than 100 GB compressed. Swiss-Prot-only and docs-only subsets cannot identify the estimand. This does not show that the predictor is impossible, that eligible cohorts fail numerically, or that the benchmark would fail in a high-storage streaming environment.

Status: active/blocked pending a high-storage streaming environment or an official smaller historical TrEMBL distribution. No accession-level transitions were read and no outcome model or executable outcome lock was created.
