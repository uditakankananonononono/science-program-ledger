# DOC-2-074 R0 source/transport audit - 2026-09-22

Verdict: SOURCE/TRANSPORT NEGATIVE under the available compute envelope. Official historical snapshots exist, but the only complete historical knowledgebase distribution is a monolithic whole-KB archive measured in tens to >100 GB compressed. It cannot be fetched, retained, unpacked, and streamed twice in this lane's ~2 GB RAM / ephemeral workspace safely. The Swiss-Prot-only archive is smaller but cannot define the required baseline population of unreviewed TrEMBL proteins. Docs-only archives omit the sequences/entry records needed for the benchmark. No current-record API, UniSave per-accession query, mirror, scrape, or reconstructed snapshot is an acceptable substitute.

Candidate releases identified without accession transition access:
- Development candidate: UniProt 2023_01, release notes dated 1 Mar 2023; official previous-release root and knowledgebase archive exist.
- Evaluation candidate: UniProt 2023_05, 8 Nov 2023; official release notes/archive exist. Swiss-Prot relstat reports 570,420 reviewed entries and 280,018 revised annotations, showing substantial release activity but not the required accession-transition count.
- Official 2026_01 index illustrates current archive scale: complete knowledgebase tar 151 GB, Swiss-Prot-only 1.6 GB, docs-only 392 MB. Older official complete archives are still tens of GB (e.g. 2018_07 index reports 71 GB), so selecting an older pair does not make whole-TrEMBL transport manageable.

Schema feasibility in principle: UniProtKB flat/XML records carry stable accessions, sequence, organism/taxonomy, reviewed/TrEMBL section identity, function comments, GO cross-references with evidence, and provenance. The complete release archives can therefore support the requested outcome hierarchy and mapping in principle. This was not tested on accession rows because Stage 0 forbids transition access before approval.

Gates not established:
- >=5,000 eligible unreviewed proteins: plausible from release totals, but not audited from records.
- >=250 later reviewed or experimentally supported gains: not established; aggregate release statistics do not distinguish this hierarchy.
- >=10 taxa: plausible, not audited.
- Exact archive bytes and cryptographic hashes: metalink endpoints are present, but could not be read reliably in this runtime and payloads were not downloaded. Rounded directory sizes are not sufficient for a lock.
- Manageable CPU/RAM/storage: FAIL.

Close R0 as source/transport negative. Do not create an executable outcome lock and do not read accession-level transitions.
